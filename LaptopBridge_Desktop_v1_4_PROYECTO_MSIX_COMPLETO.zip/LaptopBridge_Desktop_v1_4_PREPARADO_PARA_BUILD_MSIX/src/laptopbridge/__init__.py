"""LaptopBridge 1.1: local file engine with authorized Windows folders."""
__version__ = '1.2.0'

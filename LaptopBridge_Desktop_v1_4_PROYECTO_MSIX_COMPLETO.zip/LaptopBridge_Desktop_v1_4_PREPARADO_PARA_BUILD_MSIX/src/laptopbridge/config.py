"""Trusted configuration. MCP clients never get a mutation tool for this store."""
import json
import os
from pathlib import Path
import re
import tempfile
import uuid
from .errors import BridgeError

DEFAULTS = {
    'version': 1, 'paused': False, 'roots': [],
    'limits': {'max_read_bytes': 1048576, 'max_write_bytes': 5242880,
               'max_copy_bytes': 524288000, 'max_tree_items': 2000,
               'max_delete_paths': 20, 'max_results': 200, 'approval_seconds': 60},
}


def default_home():
    # Prefer Windows per-user state; do not use a directory supplied by clients.
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local'))
        return base / 'LaptopBridge'
    return Path.home() / '.local' / 'state' / 'LaptopBridge'


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, candidate = tempfile.mkstemp(prefix='.writing-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(candidate, path)
    finally:
        if os.path.exists(candidate):
            os.unlink(candidate)


class State:
    def __init__(self, home=None):
        self.home = Path(home) if home else default_home()
        self.home.mkdir(parents=True, exist_ok=True)
        self.file = self.home / 'policy.json'
        self.backups = self.home / 'backups'
        self.backups.mkdir(exist_ok=True)
        if not self.file.exists():
            atomic_json(self.file, DEFAULTS)

    def read(self):
        try:
            doc = json.loads(self.file.read_text(encoding='utf-8'))
            if doc.get('version') != 1 or not isinstance(doc.get('roots'), list):
                raise ValueError('schema')
            return doc
        except (ValueError, OSError, TypeError) as exc:
            raise BridgeError('CONFIG_ERROR', 'La política local no se puede verificar') from exc

    def set_pause(self, paused):
        doc = self.read()
        doc['paused'] = bool(paused)
        atomic_json(self.file, doc)

    def list_roots(self):
        return [{'id': r['id'], 'name': r['name']} for r in self.read()['roots']]

    def root(self, root_id):
        if not isinstance(root_id, str) or not re.fullmatch(r'[a-f0-9]{32}', root_id):
            raise BridgeError('ACCESS_DENIED', 'Identificador de carpeta no autorizado')
        doc = self.read()
        if doc['paused']:
            raise BridgeError('PAUSED', 'LaptopBridge está pausado desde el panel local')
        for r in doc['roots']:
            if r['id'] == root_id:
                root = Path(r['path'])
                try:
                    info = root.stat()
                except OSError as exc:
                    raise BridgeError('ACCESS_DENIED', 'La carpeta autorizada ya no existe') from exc
                if [info.st_dev, info.st_ino] != r.get('identity'):
                    raise BridgeError('STALE_ROOT', 'La carpeta autorizada fue reemplazada; vuelve a conceder permiso')
                return root
        raise BridgeError('ACCESS_DENIED', 'Carpeta no autorizada')

    def add_root(self, path, name=None):
        """Only local GUI calls this method. Never expose it as an MCP tool."""
        from .paths import verify_root, is_within
        p = verify_root(Path(path), self.home)
        doc = self.read()
        for item in doc['roots']:
            existing = Path(item['path'])
            if is_within(p, existing) or is_within(existing, p):
                raise BridgeError('ROOT_OVERLAP', 'La carpeta se superpone con otra autorización')
        label = (name or p.name).strip()[:80]
        if not label:
            raise BridgeError('INVALID_NAME', 'Nombre vacío')
        st = p.stat()
        root = {'id': uuid.uuid4().hex, 'name': label, 'path': str(p),
                'identity': [st.st_dev, st.st_ino]}
        doc['roots'].append(root)
        atomic_json(self.file, doc)
        return root

    def remove_root(self, root_id):
        doc = self.read()
        before = len(doc['roots'])
        doc['roots'] = [r for r in doc['roots'] if r['id'] != root_id]
        if len(doc['roots']) == before:
            raise BridgeError('NOT_FOUND', 'Carpeta desconocida')
        atomic_json(self.file, doc)

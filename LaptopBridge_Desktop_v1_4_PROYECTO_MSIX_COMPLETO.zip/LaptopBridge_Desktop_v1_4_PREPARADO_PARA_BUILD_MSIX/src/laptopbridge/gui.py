"""Locally controlled root grants, pause, and audit UI (not exposed via MCP)."""
from .config import State
from .audit import Audit
from .errors import BridgeError


def launch():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox, simpledialog

    state = State()
    audit = Audit(state.home)
    app = tk.Tk()
    app.title('LaptopBridge — Panel de control local')
    app.geometry('850x580')
    app.minsize(720, 460)
    wrapper = ttk.Frame(app, padding=18)
    wrapper.pack(fill='both', expand=True)
    ttk.Label(wrapper, text='LaptopBridge', font=('Segoe UI', 19, 'bold')).pack(anchor='w')
    ttk.Label(wrapper, text='Autorizaciones locales • Ninguna solicitud MCP puede modificar esta lista.').pack(anchor='w', pady=(0, 16))
    top = ttk.Frame(wrapper)
    top.pack(fill='x')
    pause_state = tk.BooleanVar(value=state.read()['paused'])
    def change_pause():
        state.set_pause(pause_state.get())
        refresh()
    ttk.Checkbutton(top, text='Pausar todas las operaciones de archivos', variable=pause_state,
                    command=change_pause).pack(side='left')
    ttk.Label(wrapper, text='Carpetas autorizadas', font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=(18, 4))
    tree = ttk.Treeview(wrapper, columns=('name', 'path'), show='headings', height=7)
    tree.heading('name', text='Etiqueta')
    tree.heading('path', text='Ruta local (solo visible aquí)')
    tree.column('name', width=200)
    tree.column('path', width=570)
    tree.pack(fill='x')
    buttons = ttk.Frame(wrapper)
    buttons.pack(fill='x', pady=7)

    def add():
        folder = filedialog.askdirectory(parent=app, title='Autorizar una carpeta específica')
        if not folder:
            return
        if not messagebox.askyesno('Confirmar autorización',
                                   f'LaptopBridge podrá leer, crear, mover y modificar archivos dentro de:\n\n{folder}\n\n'
                                   'Las eliminaciones exigirán una segunda confirmación local.', parent=app):
            return
        label = simpledialog.askstring('Nombre', 'Etiqueta de carpeta:', initialvalue=folder.rsplit('/', 1)[-1],
                                       parent=app)
        if label is None:
            return
        try:
            state.add_root(folder, label)
            refresh()
        except BridgeError as ex:
            messagebox.showerror('Carpeta rechazada', f'{ex.code}: {ex}', parent=app)

    def revoke():
        selected = tree.selection()
        if not selected:
            return
        root_id = selected[0]
        if messagebox.askyesno('Revocar permiso',
                               '¿Revocar esta carpeta para todas las sesiones MCP?', parent=app):
            try:
                state.remove_root(root_id)
                refresh()
            except BridgeError as ex:
                messagebox.showerror('Error', str(ex), parent=app)

    ttk.Button(buttons, text='Autorizar carpeta…', command=add).pack(side='left', padx=(0, 8))
    ttk.Button(buttons, text='Revocar seleccionada', command=revoke).pack(side='left', padx=(0, 8))
    ttk.Button(buttons, text='Actualizar', command=lambda: refresh()).pack(side='left')
    ttk.Label(wrapper, text='Registro de operaciones recientes (sin contenido)',
              font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=(18, 4))
    log = ttk.Treeview(wrapper, columns=('date', 'action', 'target', 'status'), show='headings', height=8)
    for field, title, width in [('date','Fecha UTC',195), ('action','Acción',135),
                                ('target','Ruta relativa',330), ('status','Resultado',115)]:
        log.heading(field, text=title)
        log.column(field, width=width)
    log.pack(fill='both', expand=True)
    status = ttk.Label(wrapper, text='')
    status.pack(anchor='w', pady=(9, 0))

    def refresh():
        for item in tree.get_children():
            tree.delete(item)
        doc = state.read()
        for item in doc['roots']:
            tree.insert('', 'end', iid=item['id'], values=(item['name'], item['path']))
        for item in log.get_children():
            log.delete(item)
        for item in audit.recent(50):
            log.insert('', 'end', values=(item['when_utc'][:19], item['action'],
                                         item['target'], item['outcome']))
        status.configure(text=f"Estado: {'PAUSADO' if doc['paused'] else 'ACTIVO'} | "
                              f"{len(doc['roots'])} carpetas autorizadas | "
                              'La interfaz MCP debe iniciarse por separado.')
        pause_state.set(doc['paused'])
    refresh()
    app.mainloop()

"""Windows Explorer recycle bin only. Fail closed on other operating systems."""
import os
from .errors import BridgeError


def move_to_recycle_bin(path):
    if os.name != 'nt':
        raise BridgeError('RECYCLE_BIN_UNAVAILABLE', 'La Papelera de Windows no está disponible aquí')
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ('hwnd', wintypes.HWND), ('wFunc', wintypes.UINT),
            ('pFrom', wintypes.LPCWSTR), ('pTo', wintypes.LPCWSTR),
            ('fFlags', wintypes.WORD), ('fAnyOperationsAborted', wintypes.BOOL),
            ('hNameMappings', ctypes.c_void_p), ('lpszProgressTitle', wintypes.LPCWSTR),
        ]

    absolute = str(path.absolute())
    if not os.path.isabs(absolute):
        raise BridgeError('INVALID_PATH', 'Eliminación requiere ruta absoluta')
    # Only fixed local volumes: network/removable drives may not have a recycle bin.
    volume = str(path.anchor)
    drive_type = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(volume))
    if drive_type != 3:  # DRIVE_FIXED
        raise BridgeError('RECYCLE_BIN_UNAVAILABLE', 'Solo se admite Papelera en discos locales fijos')
    # Full absolute path, required to prevent accidental irreversible deletion.
    source = ctypes.create_unicode_buffer(absolute + '\0\0')
    flags = 0x0040 | 0x0010  # FOF_ALLOWUNDO + FOF_NOCONFIRMATION after our own local approval
    op = SHFILEOPSTRUCTW(None, 0x0003, ctypes.cast(source, wintypes.LPCWSTR),
                         None, flags, False, None, None)
    code = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if code != 0 or op.fAnyOperationsAborted or os.path.lexists(absolute):
        raise BridgeError('RECYCLE_FAILED', f'No se confirmó traslado a Papelera (código {code})')

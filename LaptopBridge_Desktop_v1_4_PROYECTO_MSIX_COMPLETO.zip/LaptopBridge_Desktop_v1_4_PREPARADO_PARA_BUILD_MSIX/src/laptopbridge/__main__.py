import argparse
import json
import platform
from .config import State


def main():
    p = argparse.ArgumentParser(prog='laptopbridge', description='Agente local de archivos Windows 11')
    p.add_argument('command', choices=['gui', 'mcp', 'doctor'])
    args = p.parse_args()
    if args.command == 'gui':
        from .gui import launch
        launch()
    elif args.command == 'mcp':
        from .mcp_stdio import run_stdio
        run_stdio()
    elif args.command == 'doctor':
        s = State()
        d = s.read()
        print(json.dumps({'version': '1.4.0', 'os': platform.system(),
                          'windows_11_target': platform.system() == 'Windows',
                          'state_directory': str(s.home), 'authorized_root_count': len(d['roots']),
                          'paused': d['paused'],
                          'delete_support': 'Windows interactive Recycle Bin' if platform.system() == 'Windows' else 'disabled',
                          'mcp_transport': 'stdio', 'public_network_listener': False},
                         indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()

"""Blocking local human approval. Never remotely callable as MCP approval."""
import os
import threading


def confirm_delete(items, ttl_seconds=60):
    # Local interactive Windows desktop required; never auto-approve on headless.
    if os.name != 'nt' or threading.current_thread() is not threading.main_thread():
        return False
    try:
        import tkinter as tk
        from tkinter import ttk
        root = tk.Tk()
        root.title('LaptopBridge — Confirmar eliminación')
        root.resizable(False, False)
        root.attributes('-topmost', True)
        root.geometry('560x360')
        approved = [False]
        ttk.Label(root, text='Solicitar traslado a la Papelera',
                  font=('Segoe UI', 12, 'bold')).pack(pady=12)
        ttk.Label(root, text='Escribe ELIMINAR para autorizar esta solicitud.',
                  wraplength=520).pack()
        box = tk.Text(root, width=70, height=9, wrap='none')
        box.pack(padx=14, pady=9)
        box.insert('1.0', '\n'.join(items))
        box.configure(state='disabled')
        typed = tk.StringVar()
        field = ttk.Entry(root, textvariable=typed, width=40)
        field.pack(pady=8)
        def accept():
            if typed.get() == 'ELIMINAR':
                approved[0] = True
                root.destroy()
        ttk.Button(root, text='Confirmar eliminación', command=accept).pack(side='right', padx=20, pady=12)
        ttk.Button(root, text='Cancelar', command=root.destroy).pack(side='left', padx=20, pady=12)
        root.after(max(1, ttl_seconds) * 1000, lambda: root.destroy() if root.winfo_exists() else None)
        root.protocol('WM_DELETE_WINDOW', root.destroy)
        field.focus_set()
        root.mainloop()
        return approved[0]
    except Exception:
        return False

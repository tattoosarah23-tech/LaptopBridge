import sqlite3
from contextlib import closing
from datetime import datetime, timezone


class Audit:
    def __init__(self, home):
        self.path = home / 'audit.sqlite3'
        with closing(sqlite3.connect(self.path, timeout=10)) as db, db:
            db.execute('''CREATE TABLE IF NOT EXISTS events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                when_utc TEXT NOT NULL, action TEXT NOT NULL,
                target TEXT NOT NULL, outcome TEXT NOT NULL, detail TEXT NOT NULL)''')

    def write(self, action, target, outcome, detail=''):
        # No file content or secrets in audit records.
        with closing(sqlite3.connect(self.path, timeout=10)) as db, db:
            db.execute('INSERT INTO events(when_utc,action,target,outcome,detail) VALUES (?,?,?,?,?)',
                       (datetime.now(timezone.utc).isoformat(), action[:80], target[:500],
                        outcome[:60], detail[:200]))

    def recent(self, limit=100):
        with closing(sqlite3.connect(self.path, timeout=10)) as db, db:
            db.row_factory = sqlite3.Row
            return [dict(r) for r in db.execute(
                'SELECT * FROM events ORDER BY event_id DESC LIMIT ?', (min(max(int(limit), 1), 200),))]

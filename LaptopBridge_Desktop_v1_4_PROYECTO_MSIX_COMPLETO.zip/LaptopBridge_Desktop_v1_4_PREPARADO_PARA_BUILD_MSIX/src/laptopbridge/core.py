"""Filesystem engine. No shell, arbitrary command execution, or remote permission changes."""
import difflib
import fnmatch
import hashlib
import json
import os
import shutil
import stat
import tempfile
import time
import uuid
from pathlib import Path

from .approval import confirm_delete
from .audit import Audit
from .config import State, atomic_json
from .errors import BridgeError
from .paths import Guard, is_reparse, safe_components
from .recycle import move_to_recycle_bin


def digest(path):
    h = hashlib.sha256()
    # O_NOFOLLOW mitigates link swaps for the final component on platforms supporting it.
    flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(path, flags)
    with os.fdopen(fd, 'rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def check_file(path):
    if not path.is_file() or is_reparse(path):
        raise BridgeError('UNSUPPORTED_TYPE', 'Solo archivos normales; enlaces y dispositivos denegados')
    if path.stat().st_nlink > 1:
        raise BridgeError('HARDLINK_DENIED', 'Archivo con hardlinks; acceso remoto denegado')


def fingerprint(path):
    st = path.lstat()
    return [st.st_dev, st.st_ino, st.st_mode, st.st_size, st.st_mtime_ns]


class Bridge:
    def __init__(self, state=None, approval=None, recycle=None):
        self.state = state or State()
        self.guard = Guard(self.state)
        self.audit = Audit(self.state.home)
        self.approval = approval or confirm_delete
        self.recycle = recycle or move_to_recycle_bin
        self.plans = {}  # ephemeral and non-transferable; restart invalidates plans

    def limit(self, name):
        return int(self.state.read()['limits'][name])

    def _ensure_parent(self, path):
        if not path.parent.is_dir() or is_reparse(path.parent):
            raise BridgeError('INVALID_PATH', 'Directorio padre inexistente o no autorizado')

    def _tree(self, path):
        """Bounded fingerprint over an entire directory; reject symlinks/reparse anywhere."""
        entries, total = [], 0
        def accept(p):
            nonlocal total
            if is_reparse(p):
                raise BridgeError('REPARSE_POINT_DENIED', 'Árbol contiene enlace/reparse point')
            st = p.lstat()
            if not (stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode)):
                raise BridgeError('UNSUPPORTED_TYPE', 'Tipo especial no admitido')
            if stat.S_ISREG(st.st_mode) and st.st_nlink > 1:
                raise BridgeError('HARDLINK_DENIED', 'Árbol contiene archivo con hardlinks')
            total += st.st_size if stat.S_ISREG(st.st_mode) else 0
            if len(entries) >= self.limit('max_tree_items') or total > self.limit('max_copy_bytes'):
                raise BridgeError('SIZE_LIMIT', 'Árbol excede límites de seguridad')
            entries.append((str(p.relative_to(path)), fingerprint(p)))
        accept(path)
        if path.is_dir():
            for base, dirs, files in os.walk(path, followlinks=False):
                for name in sorted(dirs + files):
                    accept(Path(base) / name)
        data = json.dumps(sorted(entries), ensure_ascii=False).encode()
        return {'items': len(entries), 'bytes': total,
                'fingerprint': hashlib.sha256(data).hexdigest()}

    def _backup_file(self, path, root_id, relative):
        if not path.is_file():
            raise BridgeError('BACKUP_FAILED', 'No se permite sobrescribir directorios')
        backup_id = uuid.uuid4().hex
        target = self.state.backups / (backup_id + '.bin')
        before = digest(path)
        try:
            shutil.copy2(path, target, follow_symlinks=False)
            if digest(target) != before:
                raise OSError('backup hash mismatch')
            atomic_json(self.state.backups / (backup_id + '.json'),
                        {'id': backup_id, 'root_id': root_id, 'relative_path': relative,
                         'sha256': before, 'created_unix': time.time()})
        except Exception as exc:
            target.unlink(missing_ok=True)
            raise BridgeError('BACKUP_FAILED', 'No se pudo guardar la versión anterior') from exc
        return backup_id

    def _content_checksum(self, path):
        """Content checksum for a complete bounded tree; for directory restores."""
        self._tree(path)  # enforces maximum size, objects and reparse prohibition
        h = hashlib.sha256()
        if path.is_file():
            h.update(digest(path).encode('ascii'))
        else:
            for base, dirs, files in os.walk(path, followlinks=False):
                dirs.sort()
                for name in sorted(dirs + files):
                    p = Path(base) / name
                    if is_reparse(p):
                        raise BridgeError('REPARSE_POINT_DENIED', 'Árbol cambió durante respaldo')
                    h.update(str(p.relative_to(path)).encode('utf-8'))
                    h.update(b'\0')
                    if p.is_file():
                        h.update(digest(p).encode('ascii'))
        return h.hexdigest()

    def _backup_deleted(self, path, root_id, relative):
        """Make an independent restore point before any destructive request."""
        backup_id = uuid.uuid4().hex
        is_dir = path.is_dir()
        backup = self.state.backups / (backup_id + ('.tree' if is_dir else '.bin'))
        before = self._tree(path)
        content_hash = self._content_checksum(path)
        try:
            if is_dir:
                shutil.copytree(path, backup, symlinks=True)
                stored = self._tree(backup)
                if stored['items'] != before['items'] or stored['bytes'] != before['bytes']:
                    raise OSError('directory backup changed')
            else:
                shutil.copy2(path, backup, follow_symlinks=False)
                if digest(backup) != digest(path):
                    raise OSError('file backup changed')
            if self._tree(path)['fingerprint'] != before['fingerprint']:
                raise OSError('target changed while copying')
            if (self._content_checksum(backup) != content_hash or
                    self._content_checksum(path) != content_hash):
                raise OSError('content checksum mismatch')
            atomic_json(self.state.backups / (backup_id + '.json'),
                        {'id': backup_id, 'root_id': root_id, 'relative_path': relative,
                         'kind': 'directory' if is_dir else 'file',
                         'created_unix': time.time(), 'bytes': before['bytes'],
                         'content_sha256': content_hash})
            return backup_id
        except Exception as exc:
            if backup.is_dir():
                shutil.rmtree(backup)
            else:
                backup.unlink(missing_ok=True)
            raise BridgeError('BACKUP_FAILED', 'No se pudo conservar respaldo previo a eliminación') from exc

    def list_roots(self):
        return {'roots': self.state.list_roots(), 'paused': self.state.read()['paused']}

    def files_list(self, root_id, relative_path='.', depth=1, limit=100):
        if not isinstance(depth, int) or not 0 <= depth <= 5:
            raise BridgeError('INVALID_INPUT', 'depth permitido: 0..5')
        if not isinstance(limit, int) or not 1 <= limit <= self.limit('max_results'):
            raise BridgeError('INVALID_INPUT', 'limit inválido')
        folder = self.guard.resolve(root_id, relative_path, root_allowed=True, exists=True)
        if not folder.is_dir():
            raise BridgeError('INVALID_PATH', 'No es carpeta')
        root = self.state.root(root_id)
        found = []
        def scan(current, level):
            if len(found) >= limit or level >= depth:
                return
            for entry in sorted(current.iterdir(), key=lambda p: p.name.lower()):
                if len(found) >= limit:
                    break
                blocked = is_reparse(entry)
                found.append({'path': entry.relative_to(root).as_posix(),
                              'kind': 'blocked_link' if blocked else ('directory' if entry.is_dir() else 'file'),
                              'bytes': None if blocked else entry.lstat().st_size})
                if not blocked and entry.is_dir():
                    scan(entry, level + 1)
        scan(folder, 0)
        return {'entries': found, 'truncated': len(found) >= limit}

    def files_stat(self, root_id, relative_path):
        p = self.guard.resolve(root_id, relative_path, exists=True)
        st = p.stat()
        if p.is_file():
            check_file(p)
        return {'path': relative_path, 'kind': 'directory' if p.is_dir() else 'file',
                'bytes': st.st_size, 'modified_unix': st.st_mtime,
                'sha256': digest(p) if p.is_file() and st.st_size <= self.limit('max_read_bytes') else None}

    def files_read_text(self, root_id, relative_path, max_bytes=1048576):
        if not isinstance(max_bytes, int) or max_bytes < 1 or max_bytes > self.limit('max_read_bytes'):
            raise BridgeError('SIZE_LIMIT', 'Límite de lectura inválido')
        p = self.guard.resolve(root_id, relative_path, exists=True)
        check_file(p)
        if p.stat().st_size > max_bytes:
            raise BridgeError('SIZE_LIMIT', 'Archivo supera el límite configurado')
        flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
        fd = os.open(p, flags)
        with os.fdopen(fd, 'rb') as fh:
            raw = fh.read(max_bytes + 1)
        if len(raw) > max_bytes:
            raise BridgeError('SIZE_LIMIT', 'Archivo creció durante lectura')
        try:
            content = raw.decode('utf-8-sig')
        except UnicodeDecodeError as exc:
            raise BridgeError('NOT_TEXT', 'El archivo no es UTF-8') from exc
        return {'content': content, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

    def files_search(self, root_id, pattern='*', relative_path='.', limit=50):
        if not isinstance(pattern, str) or len(pattern) > 160 or not pattern or '/' in pattern or '\\' in pattern:
            raise BridgeError('INVALID_INPUT', 'Patrón de nombre inválido')
        if not isinstance(limit, int) or not 1 <= limit <= self.limit('max_results'):
            raise BridgeError('INVALID_INPUT', 'Límite de búsqueda inválido')
        base = self.guard.resolve(root_id, relative_path, root_allowed=True, exists=True)
        if not base.is_dir():
            raise BridgeError('INVALID_PATH', 'Buscar requiere carpeta')
        root = self.state.root(root_id)
        results = []
        scanned = 0
        max_scan = self.limit('max_tree_items')
        for here, dirs, files in os.walk(base, followlinks=False):
            dirs[:] = [name for name in dirs if not is_reparse(Path(here) / name)]
            for name in dirs + files:
                path = Path(here) / name
                if is_reparse(path):
                    continue
                scanned += 1
                if scanned > max_scan:
                    return {'matches': results, 'truncated': True, 'reason': 'scan_limit'}
                if fnmatch.fnmatchcase(name.casefold(), pattern.casefold()):
                    results.append(path.relative_to(root).as_posix())
                    if len(results) >= limit:
                        return {'matches': results, 'truncated': True}
        return {'matches': results, 'truncated': False}

    def files_mkdir(self, root_id, relative_path):
        p = self.guard.resolve(root_id, relative_path, exists=False)
        self._ensure_parent(p)
        p.mkdir()
        return {'created': relative_path}

    def files_write_text(self, root_id, relative_path, content, overwrite=False, expected_sha256=None):
        if not isinstance(content, str):
            raise BridgeError('INVALID_INPUT', 'content debe ser texto')
        raw = content.encode('utf-8')
        if len(raw) > self.limit('max_write_bytes'):
            raise BridgeError('SIZE_LIMIT', 'Texto supera el máximo admitido')
        p = self.guard.resolve(root_id, relative_path)
        self._ensure_parent(p)
        backup_id = None
        if os.path.lexists(p):
            check_file(p)
            self.guard.ensure_single_link(p)
            if not overwrite or not isinstance(expected_sha256, str) or digest(p) != expected_sha256:
                raise BridgeError('CONFLICT', 'Para sobrescribir se necesita SHA256 actual exacto')
            backup_id = self._backup_file(p, root_id, relative_path)
        elif overwrite:
            raise BridgeError('CONFLICT', 'No existe archivo para sobrescribir')
        fd, tempname = tempfile.mkstemp(prefix='.laptopbridge-', dir=p.parent)
        try:
            with os.fdopen(fd, 'wb') as dest:
                dest.write(raw)
                dest.flush()
                os.fsync(dest.fileno())
            # A second guard prevents common path swaps, but is not an OS-level sandbox.
            self.guard.resolve(root_id, relative_path)
            if backup_id and digest(p) != expected_sha256:
                raise BridgeError('STALE_TARGET', 'El contenido cambió después del backup')
            if backup_id:
                os.replace(tempname, p)
            else:
                # Exclusive creation; os.replace would silently overwrite a race winner.
                with open(p, 'xb') as f:
                    f.write(raw)
                    f.flush()
                    os.fsync(f.fileno())
        finally:
            Path(tempname).unlink(missing_ok=True)
        return {'written': relative_path, 'bytes': len(raw),
                'sha256': hashlib.sha256(raw).hexdigest(), 'backup_id': backup_id}

    def files_diff(self, root_id, relative_path, proposed_content):
        if not isinstance(proposed_content, str) or len(proposed_content.encode('utf-8')) > self.limit('max_write_bytes'):
            raise BridgeError('SIZE_LIMIT', 'Propuesta demasiado grande')
        current = self.files_read_text(root_id, relative_path)
        lines = difflib.unified_diff(current['content'].splitlines(keepends=True),
                                     proposed_content.splitlines(keepends=True),
                                     fromfile='actual', tofile='propuesto')
        preview = ''.join(lines)
        return {'diff': preview[:20000], 'truncated': len(preview) > 20000,
                'expected_sha256': current['sha256']}

    def files_copy(self, src_root_id, src_relative_path, dst_root_id, dst_relative_path):
        src = self.guard.resolve(src_root_id, src_relative_path, exists=True)
        dst = self.guard.resolve(dst_root_id, dst_relative_path, exists=False)
        self._ensure_parent(dst)
        if src == dst or (src.is_dir() and str(dst).startswith(str(src) + os.sep)):
            raise BridgeError('INVALID_PATH', 'No copiar una carpeta dentro de sí misma')
        summary = self._tree(src)
        source_content_sha256 = self._content_checksum(src)
        if src.is_dir():
            try:
                shutil.copytree(src, dst, symlinks=True)
            except Exception:
                # A failed copy may leave a partial directory. Do not blindly remove it.
                raise BridgeError('IO_ERROR', 'Copia fallida; revisar posible destino parcial')
        else:
            # x mode means no overwrite even if another process created destination.
            with open(src, 'rb') as in_fh, open(dst, 'xb') as out_fh:
                shutil.copyfileobj(in_fh, out_fh, 1024 * 1024)
        self.guard.resolve(dst_root_id, dst_relative_path, exists=True)
        copied_summary = self._tree(dst)  # Reject links inserted into target after copy.
        if copied_summary['items'] != summary['items'] or copied_summary['bytes'] != summary['bytes']:
            raise BridgeError('STALE_TARGET', 'La copia resultante no coincide con el origen')
        # Same-length data corruption must not pass a metadata-only comparison.
        if self._content_checksum(dst) != source_content_sha256:
            raise BridgeError('STALE_TARGET', 'La copia no coincide byte a byte con el origen')
        if (summary['fingerprint'] != self._tree(src)['fingerprint']
                or self._content_checksum(src) != source_content_sha256):
            raise BridgeError('STALE_TARGET', 'La fuente cambió durante copia; revisar resultado')
        return {'copied': dst_relative_path, 'items': summary['items'], 'bytes': summary['bytes'],
                'content_sha256': source_content_sha256}

    def files_move(self, src_root_id, src_relative_path, dst_root_id, dst_relative_path):
        src = self.guard.resolve(src_root_id, src_relative_path, exists=True)
        dst = self.guard.resolve(dst_root_id, dst_relative_path, exists=False)
        self._ensure_parent(dst)
        if src == dst or (src.is_dir() and str(dst).startswith(str(src) + os.sep)):
            raise BridgeError('INVALID_PATH', 'Destino inválido')
        self._tree(src)
        if src.stat().st_dev != dst.parent.stat().st_dev:
            raise BridgeError('CROSS_DEVICE_DENIED', 'Movimiento entre discos no habilitado; usa copiar')
        # On Windows os.rename fails if dest exists. Never use os.replace here.
        os.rename(src, dst)
        return {'moved': src_relative_path, 'to': dst_relative_path}

    def files_rename(self, root_id, relative_path, new_name):
        parts = safe_components(new_name)
        if len(parts) != 1:
            raise BridgeError('INVALID_PATH', 'El nuevo nombre debe ser un solo componente')
        p = self.guard.resolve(root_id, relative_path, exists=True)
        parent = '/'.join(safe_components(relative_path)[:-1])
        dest_rel = f'{parent}/{new_name}' if parent else new_name
        return self.files_move(root_id, relative_path, root_id, dest_rel)

    def files_plan_delete(self, root_id, relative_paths):
        if not isinstance(relative_paths, list) or not 1 <= len(relative_paths) <= self.limit('max_delete_paths'):
            raise BridgeError('INVALID_INPUT', 'Lista de eliminación inválida')
        if any(not isinstance(p, str) for p in relative_paths) or len(set(relative_paths)) != len(relative_paths):
            raise BridgeError('INVALID_INPUT', 'Rutas repetidas o inválidas')
        verified = []
        for rel in relative_paths:
            p = self.guard.resolve(root_id, rel, exists=True)
            verified.append({'path': rel, 'tree': self._tree(p)})
        # Refuse parent-child redundancies.
        chunks = [tuple(safe_components(p)) for p in relative_paths]
        if any(a != b and len(a) < len(b) and b[:len(a)] == a for a in chunks for b in chunks):
            raise BridgeError('INVALID_INPUT', 'No repitas rutas hijas dentro de otra carpeta')
        plan_id = uuid.uuid4().hex
        ttl = self.limit('approval_seconds')
        self.plans[plan_id] = {'root_id': root_id, 'entries': verified,
                               'expires': time.monotonic() + ttl}
        return {'plan_id': plan_id, 'expires_seconds': ttl,
                'items': verified, 'effect': 'local_recycle_bin_only',
                'requires_local_confirmation': True}

    def files_delete(self, plan_id):
        if not isinstance(plan_id, str) or plan_id not in self.plans:
            raise BridgeError('APPROVAL_REQUIRED', 'Plan inexistente o ya consumido')
        plan = self.plans.pop(plan_id)  # one-time token regardless of outcome
        if time.monotonic() >= plan['expires']:
            raise BridgeError('APPROVAL_EXPIRED', 'Plan caducado')
        root_id = plan['root_id']
        # Re-check before presenting local approval and before each delete.
        for item in plan['entries']:
            p = self.guard.resolve(root_id, item['path'], exists=True)
            if self._tree(p) != item['tree']:
                raise BridgeError('STALE_TARGET', 'El archivo o carpeta cambió desde el plan')
        labels = [f"{self.guard.resolve(root_id, entry['path'], exists=True)}  "
                  f"({entry['tree']['items']} elementos, {entry['tree']['bytes']} bytes)"
                  for entry in plan['entries']]
        remaining = max(1, int(plan['expires'] - time.monotonic()))
        if not self.approval(labels, remaining):
            raise BridgeError('APPROVAL_DENIED', 'Eliminación cancelada o UI local no disponible')
        if time.monotonic() >= plan['expires']:
            raise BridgeError('APPROVAL_EXPIRED', 'Confirmación vencida')
        completed, backup_ids = [], []
        for item in plan['entries']:
            p = self.guard.resolve(root_id, item['path'], exists=True)
            if self._tree(p) != item['tree']:
                raise BridgeError('STALE_TARGET', 'Cambió el contenido antes de eliminar')
            backup_id = self._backup_deleted(p, root_id, item['path'])
            if self._tree(p) != item['tree']:
                raise BridgeError('STALE_TARGET', 'La fuente cambió después del respaldo')
            self.recycle(p)  # Must fail, never permanent fallback.
            completed.append(item['path'])
            backup_ids.append(backup_id)
            self.audit.write('files_delete_item', item['path'], 'RECYCLED', backup_id)
        return {'recycled': completed, 'backup_ids': backup_ids, 'permanent_delete': False,
                'note': 'Recuperación mediante Papelera o respaldo local'}

    def files_restore_snapshot(self, backup_id, expected_current_sha256=None):
        if not isinstance(backup_id, str) or len(backup_id) != 32 or any(c not in '0123456789abcdef' for c in backup_id):
            raise BridgeError('INVALID_INPUT', 'Identificador de copia inválido')
        meta_path = self.state.backups / (backup_id + '.json')
        if not meta_path.exists():
            raise BridgeError('NOT_FOUND', 'Copia no encontrada')
        meta = json.loads(meta_path.read_text(encoding='utf-8'))
        if meta.get('kind') == 'directory':
            tree_path = self.state.backups / (backup_id + '.tree')
            if not tree_path.is_dir():
                raise BridgeError('BACKUP_FAILED', 'Carpeta de respaldo no disponible')
            p = self.guard.resolve(meta['root_id'], meta['relative_path'], exists=False)
            self._ensure_parent(p)
            if self._content_checksum(tree_path) != meta['content_sha256']:
                raise BridgeError('BACKUP_FAILED', 'Contenido de respaldo modificado')
            shutil.copytree(tree_path, p, symlinks=True)
            if self._content_checksum(p) != meta['content_sha256']:
                raise BridgeError('BACKUP_FAILED', 'Restauración de carpeta incompleta')
            return {'restored': meta['relative_path'], 'backup_kind': 'directory'}
        bin_path = self.state.backups / (backup_id + '.bin')
        if not bin_path.exists():
            raise BridgeError('NOT_FOUND', 'Copia no encontrada')
        p = self.guard.resolve(meta['root_id'], meta['relative_path'])
        self._ensure_parent(p)
        if meta.get('sha256') and digest(bin_path) != meta['sha256']:
            raise BridgeError('BACKUP_FAILED', 'La copia tiene checksum inválido')
        old_backup_id = None
        if p.exists():
            check_file(p)
            self.guard.ensure_single_link(p)
            if not expected_current_sha256 or digest(p) != expected_current_sha256:
                raise BridgeError('CONFLICT', 'Se necesita SHA256 actual para restaurar')
            old_backup_id = self._backup_file(p, meta['root_id'], meta['relative_path'])
        elif expected_current_sha256:
            raise BridgeError('CONFLICT', 'El destino original ya no existe')
        tempfd, tempname = tempfile.mkstemp(prefix='.laptopbridge-restore-', dir=p.parent)
        try:
            with os.fdopen(tempfd, 'wb') as out, open(bin_path, 'rb') as source:
                shutil.copyfileobj(source, out)
                out.flush()
                os.fsync(out.fileno())
            # Revalidate before committing: no restoring stale targets.
            self.guard.resolve(meta['root_id'], meta['relative_path'])
            if p.exists():
                if digest(p) != expected_current_sha256:
                    raise BridgeError('STALE_TARGET', 'Cambió el destino durante restauración')
                os.replace(tempname, p)
            else:
                with open(tempname, 'rb') as source, open(p, 'xb') as out:
                    shutil.copyfileobj(source, out)
        finally:
            Path(tempname).unlink(missing_ok=True)
        return {'restored': meta['relative_path'], 'sha256': digest(p), 'previous_backup_id': old_backup_id}

    def invoke(self, name, args):
        """Uniform error output, audit both failures and successes. No MCP grant tools."""
        methods = {'roots_list': self.list_roots, 'files_list': self.files_list,
                   'files_stat': self.files_stat, 'files_read_text': self.files_read_text,
                   'files_search': self.files_search, 'files_mkdir': self.files_mkdir,
                   'files_write_text': self.files_write_text, 'files_diff': self.files_diff,
                   'files_copy': self.files_copy, 'files_move': self.files_move,
                   'files_rename': self.files_rename, 'files_plan_delete': self.files_plan_delete,
                   'files_delete': self.files_delete,
                   'files_restore_snapshot': self.files_restore_snapshot}
        opid = uuid.uuid4().hex
        target = str(args.get('relative_path', args.get('src_relative_path', args.get('plan_id', '')))) if isinstance(args, dict) else ''
        try:
            if name not in methods:
                raise BridgeError('UNKNOWN_TOOL', 'Herramienta no permitida')
            if not isinstance(args, dict):
                raise BridgeError('INVALID_INPUT', 'Argumentos incorrectos')
            result = methods[name](**args)
            self.audit.write(name, target, 'OK')
            return {'ok': True, 'operation_id': opid, 'data': result}
        except BridgeError as exc:
            self.audit.write(str(name), target, exc.code, str(exc))
            return {'ok': False, 'operation_id': opid, 'error_code': exc.code, 'message': str(exc)}
        except (OSError, TypeError, ValueError, KeyError) as exc:
            self.audit.write(str(name), target, 'IO_ERROR', type(exc).__name__)
            return {'ok': False, 'operation_id': opid, 'error_code': 'IO_ERROR',
                    'message': f'Operación no realizada: {type(exc).__name__}'}

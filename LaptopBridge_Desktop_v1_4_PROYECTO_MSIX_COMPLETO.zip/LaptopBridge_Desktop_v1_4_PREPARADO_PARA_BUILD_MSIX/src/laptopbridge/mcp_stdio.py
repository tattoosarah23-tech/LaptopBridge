"""Dependency-free MCP stdio subset for standard tool discovery/calls.
JSON-RPC 2.0, newline-delimited UTF-8, protocol versions 2025-03-26/2025-06-18.
"""
import json
import sys
from .core import Bridge


def schema(fields, required=()):
    types = {
        'root_id': 'string', 'relative_path': 'string', 'src_root_id': 'string',
        'src_relative_path': 'string', 'dst_root_id': 'string',
        'dst_relative_path': 'string', 'new_name': 'string', 'content': 'string',
        'proposed_content': 'string', 'pattern': 'string', 'expected_sha256': 'string',
        'expected_current_sha256': 'string', 'backup_id': 'string',
        'plan_id': 'string', 'depth': 'integer', 'limit': 'integer',
        'max_bytes': 'integer', 'overwrite': 'boolean',
        'relative_paths': 'array',
    }
    props = {name: {'type': types[name]} for name in fields}
    if 'relative_paths' in props:
        props['relative_paths']['items'] = {'type': 'string'}
    return {'type': 'object', 'properties': props, 'required': list(required),
            'additionalProperties': False}


TOOL_ARGUMENTS = {
    'roots_list': ([], []),
    'files_list': (['root_id', 'relative_path', 'depth', 'limit'], ['root_id']),
    'files_stat': (['root_id', 'relative_path'], ['root_id', 'relative_path']),
    'files_read_text': (['root_id', 'relative_path', 'max_bytes'], ['root_id', 'relative_path']),
    'files_search': (['root_id', 'relative_path', 'pattern', 'limit'], ['root_id']),
    'files_mkdir': (['root_id', 'relative_path'], ['root_id', 'relative_path']),
    'files_write_text': (['root_id', 'relative_path', 'content', 'overwrite', 'expected_sha256'],
                         ['root_id', 'relative_path', 'content']),
    'files_diff': (['root_id', 'relative_path', 'proposed_content'],
                   ['root_id', 'relative_path', 'proposed_content']),
    'files_copy': (['src_root_id', 'src_relative_path', 'dst_root_id', 'dst_relative_path'],
                   ['src_root_id', 'src_relative_path', 'dst_root_id', 'dst_relative_path']),
    'files_move': (['src_root_id', 'src_relative_path', 'dst_root_id', 'dst_relative_path'],
                   ['src_root_id', 'src_relative_path', 'dst_root_id', 'dst_relative_path']),
    'files_rename': (['root_id', 'relative_path', 'new_name'], ['root_id', 'relative_path', 'new_name']),
    'files_plan_delete': (['root_id', 'relative_paths'], ['root_id', 'relative_paths']),
    'files_delete': (['plan_id'], ['plan_id']),
    'files_restore_snapshot': (['backup_id', 'expected_current_sha256'], ['backup_id']),
}

DESCRIPTIONS = {
    'roots_list': 'Lista raíces autorizadas localmente (sin rutas absolutas).',
    'files_list': 'Enumera archivos y subcarpetas sin seguir enlaces.',
    'files_stat': 'Consulta metadatos y SHA256 si el archivo es pequeño.',
    'files_read_text': 'Lee archivo de texto UTF-8 dentro de raíz permitida.',
    'files_search': 'Busca por patrón de nombre (glob) dentro de raíz permitida.',
    'files_mkdir': 'Crea una subcarpeta, requiere directorio padre existente.',
    'files_write_text': 'Crea/edita UTF-8; sobrescritura exige expected_sha256 y crea backup.',
    'files_diff': 'Vista previa de diferencias con el contenido propuesto.',
    'files_copy': 'Copia archivo o carpeta a destino inexistente permitido.',
    'files_move': 'Mueve o renombra sin sobrescribir, solo mismo disco.',
    'files_rename': 'Renombra dentro del directorio actual, sin sobrescribir.',
    'files_plan_delete': 'Crea plan efímero de traslado a Papelera; no elimina.',
    'files_delete': 'Pide confirmación visible local con ELIMINAR y manda a Papelera.',
    'files_restore_snapshot': 'Restaura copia previa; si sobrescribe exige SHA256 actual.',
}
TOOLS = [{'name': name, 'description': DESCRIPTIONS[name],
          'inputSchema': schema(fields, required)}
         for name, (fields, required) in TOOL_ARGUMENTS.items()]


def dispatch(bridge, request):
    """Returns None for notifications and JSON-RPC response for requests."""
    if not isinstance(request, dict) or request.get('jsonrpc') != '2.0':
        return {'jsonrpc': '2.0', 'id': request.get('id') if isinstance(request, dict) else None,
                'error': {'code': -32600, 'message': 'Invalid Request'}}
    if 'id' not in request:
        return None
    id_ = request['id']
    method = request.get('method')
    params = request.get('params') or {}
    try:
        if method == 'initialize':
            version = params.get('protocolVersion', '2025-06-18')
            if version not in ('2025-03-26', '2025-06-18', '2025-11-25'):
                version = '2025-06-18'
            data = {'protocolVersion': version,
                    'capabilities': {'tools': {'listChanged': False}},
                    'serverInfo': {'name': 'LaptopBridge', 'version': '1.4.0'}}
        elif method == 'ping':
            data = {}
        elif method == 'tools/list':
            data = {'tools': TOOLS}
        elif method == 'tools/call':
            name = params.get('name')
            arguments = params.get('arguments', {})
            if name not in TOOL_ARGUMENTS:
                raise ValueError('Unknown tool')
            if not isinstance(arguments, dict):
                raise ValueError('arguments must be object')
            allowed, required = TOOL_ARGUMENTS[name]
            if not set(required).issubset(arguments) or set(arguments) - set(allowed):
                raise ValueError('Wrong arguments')
            result = bridge.invoke(name, arguments)
            data = {'content': [{'type': 'text', 'text': json.dumps(result, ensure_ascii=False)}],
                    'isError': not result['ok']}
        else:
            return {'jsonrpc': '2.0', 'id': id_,
                    'error': {'code': -32601, 'message': 'Method not found'}}
        return {'jsonrpc': '2.0', 'id': id_, 'result': data}
    except (ValueError, AttributeError, TypeError) as exc:
        return {'jsonrpc': '2.0', 'id': id_,
                'error': {'code': -32602, 'message': 'Invalid params'}}


def run_stdio(bridge=None, source=None, sink=None):
    bridge = bridge or Bridge()
    source = source or sys.stdin.buffer
    sink = sink or sys.stdout.buffer
    while True:
        line = source.readline(8 * 1024 * 1024 + 1)
        if not line:
            return
        if len(line) > 8 * 1024 * 1024 or not line.endswith(b'\n'):
            response = {'jsonrpc': '2.0', 'id': None,
                        'error': {'code': -32700, 'message': 'Message too large/unterminated'}}
        else:
            try:
                doc = json.loads(line)
                response = dispatch(bridge, doc)
            except (json.JSONDecodeError, UnicodeDecodeError):
                response = {'jsonrpc': '2.0', 'id': None,
                            'error': {'code': -32700, 'message': 'Parse error'}}
            except Exception as exc:
                # Never crash MCP transport due to external input.
                print(f'LaptopBridge: {type(exc).__name__}', file=sys.stderr)
                response = {'jsonrpc': '2.0', 'id': None,
                            'error': {'code': -32603, 'message': 'Internal error'}}
        if response is not None:
            sink.write((json.dumps(response, ensure_ascii=False) + '\n').encode('utf-8'))
            sink.flush()

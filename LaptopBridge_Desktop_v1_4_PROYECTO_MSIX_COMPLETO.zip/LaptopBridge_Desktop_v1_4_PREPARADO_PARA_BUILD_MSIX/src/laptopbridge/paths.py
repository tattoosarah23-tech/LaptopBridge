"""Deny-by-default path rules; reject reparse/symlinks, ADS and device names.

This is not an OS sandbox. Attackers able to concurrently mutate the same tree may
still exploit TOCTOU; do not grant roots writable by untrusted local processes.
"""
import os
import re
import stat
import sys
from pathlib import Path
from .errors import BridgeError

_RESERVED = re.compile(r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$', re.I)
_DRIVE = re.compile(r'^[A-Za-z]:')


def is_within(child, parent):
    try:
        return os.path.commonpath([os.path.normcase(os.path.abspath(child)),
                                   os.path.normcase(os.path.abspath(parent))]) == os.path.normcase(os.path.abspath(parent))
    except ValueError:
        return False


def is_reparse(path):
    try:
        st = path.lstat()
    except OSError as exc:
        raise BridgeError('IO_ERROR', f'No se puede inspeccionar ruta: {path.name}') from exc
    return (stat.S_ISLNK(st.st_mode) or bool(getattr(st, 'st_file_attributes', 0) & 0x400))


def safe_components(raw, root_allowed=False):
    if not isinstance(raw, str) or len(raw) > 1024 or '\x00' in raw:
        raise BridgeError('INVALID_PATH', 'Ruta relativa inválida')
    if raw in ('', '.'):
        if root_allowed:
            return []
        raise BridgeError('INVALID_PATH', 'No se puede usar la carpeta raíz para esta operación')
    if raw.startswith(('/', '\\')) or _DRIVE.match(raw):
        raise BridgeError('INVALID_PATH', 'No se admiten rutas absolutas ni dispositivos')
    parts = raw.replace('\\', '/').split('/')
    for component in parts:
        if (component in ('', '.', '..') or component.endswith((' ', '.')) or
                ':' in component or any(ord(ch) < 32 for ch in component) or
                any(ch in '<>"|?*' for ch in component) or _RESERVED.match(component)):
            raise BridgeError('INVALID_PATH', 'Componente de ruta prohibido')
    return parts


def verify_root(root, state_home):
    if os.name == 'nt' and str(root).startswith(('\\\\', '//')):
        raise BridgeError('INVALID_ROOT', 'No se autorizan rutas de red UNC')
    if not root.is_dir():
        raise BridgeError('INVALID_ROOT', 'La carpeta seleccionada no existe')
    # Inspect the lexical path before resolving it: resolving first hides junctions.
    for segment in [root.absolute(), *root.absolute().parents]:
        if segment.exists() and is_reparse(segment):
            raise BridgeError('REPARSE_POINT_DENIED', 'Raíz contiene un enlace/reparse point')
    resolved = root.resolve(strict=True)
    if not resolved.is_absolute() or resolved == Path(resolved.anchor):
        raise BridgeError('INVALID_ROOT', 'No se permite autorizar una unidad entera')
    if is_within(state_home, resolved) or is_within(resolved, state_home):
        raise BridgeError('INVALID_ROOT', 'La carpeta incluye o contiene la configuración protegida')
    # In a packaged PyInstaller executable, __file__ resides below _internal
    # while the actual installed program is at sys.executable. Protect both.
    app_roots = [Path(__file__).resolve().parents[2]]
    if getattr(sys, 'frozen', False):
        app_roots.append(Path(sys.executable).resolve().parent)
        internal = getattr(sys, '_MEIPASS', None)
        if internal:
            app_roots.append(Path(internal).resolve())
    for app_root in app_roots:
        if is_within(app_root, resolved) or is_within(resolved, app_root):
            raise BridgeError('INVALID_ROOT', 'La carpeta incluye o contiene el programa LaptopBridge')
    if os.name == 'nt':
        env = os.environ
        protected = [env.get(x) for x in ('WINDIR', 'PROGRAMFILES', 'PROGRAMFILES(X86)', 'PROGRAMDATA')]
        for base in filter(None, protected):
            if is_within(resolved, Path(base)) or is_within(Path(base), resolved):
                raise BridgeError('INVALID_ROOT', 'Carpeta del sistema no autorizable')
    for segment in [resolved, *resolved.parents]:
        if segment.exists() and is_reparse(segment):
            raise BridgeError('REPARSE_POINT_DENIED', 'Raíz contiene un enlace/reparse point')
    return resolved


class Guard:
    def __init__(self, state):
        self.state = state

    def resolve(self, root_id, relative, *, root_allowed=False, exists=None):
        root = self.state.root(root_id)
        # Fail closed if root was replaced or turned into a junction since grant.
        verify_root(root, self.state.home)
        parts = safe_components(relative, root_allowed=root_allowed)
        target = root
        for component in parts:
            target = target / component
            if target.is_symlink():
                raise BridgeError('REPARSE_POINT_DENIED', 'Ruta contiene enlace simbólico')
            if os.path.lexists(target):
                if is_reparse(target):
                    raise BridgeError('REPARSE_POINT_DENIED', 'Ruta contiene junction/reparse point')
        if not is_within(target, root):
            raise BridgeError('ACCESS_DENIED', 'Ruta fuera de carpeta autorizada')
        if exists is True and not os.path.lexists(target):
            raise BridgeError('NOT_FOUND', 'No existe el archivo o carpeta')
        if exists is False and os.path.lexists(target):
            raise BridgeError('CONFLICT', 'El destino ya existe')
        return target

    @staticmethod
    def ensure_single_link(path):
        if path.is_file() and path.stat().st_nlink > 1:
            raise BridgeError('HARDLINK_DENIED', 'Archivo con varios hardlinks; modificación denegada')

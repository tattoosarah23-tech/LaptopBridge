# Pruebas y límites: LaptopBridge Desktop 1.1

## Automatización

15 pruebas unitarias de Python ejecutadas en Linux con Python 3.13: aislamiento de raíces, rechazo de `..`, enlaces simbólicos, raíces solapadas, cambio de identidad de raíz, respaldos, edición controlada por SHA-256, copia/movimiento, recuperación, aprobación de eliminación simulada, caducidad del plan, protocolo MCP stdio, protección de carpeta de instalación en build congelado y visualización de ruta absoluta para confirmación local.

**No cubierto con pruebas en este entorno**: ejecución de PyInstaller en Windows; firma Authenticode; bloqueo o aceptación real de Smart App Control; GUI Tkinter con escritorio Windows; API SHFileOperationW de Papelera; ejecución del cliente MCP Windows de la usuaria.

## Límites funcionales

- Solo archivos y carpetas (no control de UI de VS Code/otras apps ni PowerShell arbitrario).
- No hay acceso si laptop apagada; el proceso MCP debe mantenerse en ejecución.
- Herramienta para texto UTF-8 y copia/movimiento binarios hasta límites de política.
- No expone red/HTTP. El cliente MCP local y su seguridad quedan fuera de este proyecto.
- Las reglas de rutas son validaciones de la aplicación, **no un sandbox Windows a nivel de kernel**.
- La carpeta de respaldo puede crecer; no hay retención ni cuota automáticas.
- Carpetas sincronizadas pueden propagar movimientos y borrados.

## Criterio de aceptación en Windows 11

Ver `VALIDACION_WINDOWS11.md`. Ningún componente Windows está marcado PASS sin pruebas locales sobre equipo protegido.

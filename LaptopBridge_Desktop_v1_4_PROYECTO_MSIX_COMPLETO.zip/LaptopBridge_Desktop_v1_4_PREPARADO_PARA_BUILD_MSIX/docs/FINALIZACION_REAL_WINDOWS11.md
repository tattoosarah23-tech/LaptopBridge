# LaptopBridge v1.4 — Cierre verificable en Windows 11

## La situación real

El proyecto aún no es un producto instalado y confiable. Los tests Python no prueban Win32, la integración MCP empaquetada ni Smart App Control. No se ha generado ningún MSIX firmado.

## Para ejecutar el build de Windows fuera de tu laptop protegida

1. En https://github.com/new crea repositorio **privado** `LaptopBridge` en tu cuenta. No subas credenciales ni carpetas `backups` o `state`.
2. Sube los contenidos completos del ZIP de v1.4 como archivos del repositorio, respetando `.github/workflows/windows-build.yml` (la carpeta debe existir en la raíz).
3. Abre **Actions**, selecciona `LaptopBridge Windows + MSIX build (UNSIGNED)` y ejecuta `Run workflow` con `store_submission=false`.
4. Debe completar tests Python, compilar EXEs, ejecutar smoke test MCP, MakeAppx pack/unpack y subir dos artefactos etiquetados **UNSIGNED**. Si hay un error, detente y comparte el log del job.
5. No ejecutes ni instales ninguno de esos artefactos en tu laptop con Smart App Control.

## Para publicar un instalable de confianza

6. Registra la app en [Microsoft Partner Center](https://partner.microsoft.com/dashboard/), y obtén `Package/Identity/Name`, `Package/Identity/Publisher` y `PublisherDisplayName` exactos. Puede requerir registro, identidad legal, aceptación de términos y pago según elegibilidad y región.
7. Ejecuta el mismo workflow, `store_submission=true` e introduce los tres campos verificados.
8. Revisa el MSIX y ejecuta la prueba Windows App Certification Kit (WACK) en entorno de Windows no protegido de pruebas, después tramita el envío para revisión en Partner Center.
9. Revisa los requisitos de aprobación para `runFullTrust` y el listado de privacidad/datos. La certificación puede fallar.
10. Sólo cuando Microsoft publique y firme la app, instálala **desde la Store** manteniendo Smart App Control activado.

## Pruebas obligatorias con Windows protegido

- Abrir la app firmada y comprobar `authorized_root_count = 0`.
- Dar acceso desde el panel sólo a una carpeta temporal y verificar que no se puede acceder a carpetas vecinas.
- Validar que una lectura y una escritura se realizan dentro de la carpeta autorizada y se registra la operación.
- Generar plan de borrado, cancelar y comprobar que nada cambia. Volver a planificar, aprobar `ELIMINAR`, comprobar que el archivo se encuentra en Papelera y que existe respaldo recuperable.
- Reiniciar; comprobar que la política persiste.
- Lanzar MCP desde el alias y verificar lectura del protocolo `stdio` con cliente MCP; comprobar que `stdout` no contiene logs, y que no existen herramientas remotas de grant.
- Probar con archivos y directorios renombrados simultáneamente en una VM. **La política a nivel de aplicación aún no garantiza aislamiento ante carreras concurrentes**; efectuar revisión de seguridad o un confinamiento adicional antes de conceder acceso a material sensible.

## Alternativa sin Store

Firmar todos los binarios y paquete con certificado de confianza de CA o Artifact Signing y verificar `Get-AuthenticodeSignature` y la cadena de confianza. No hay certificado incluido en este ZIP.

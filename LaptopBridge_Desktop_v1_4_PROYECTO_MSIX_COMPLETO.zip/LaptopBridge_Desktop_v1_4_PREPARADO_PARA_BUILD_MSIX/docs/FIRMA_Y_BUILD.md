# Firma y build

Ver `GUIA_COMPILACION_Y_PUBLICACION.md` para la secuencia actualizada de v1.2.

- Build PyInstaller en Windows con Python 3.13 y paquete `--onedir`.
- Inventario PE detecta MZ y rechaza dependencias PE bajo extensión no esperada.
- Firma Authenticode de EXE principales y DLL/PYD/OCX sin firma con cert RSA de publicador; verifica cadena para todas las dependencias.
- Firma temporal con SHA-256 y servidor RFC3161.
- El verificador final exige SHA256.json/PUBLISHER.json e identidad del publicador en las dos aplicaciones principales.
- Un certificado autofirmado no sirve para distribución general.
- Microsoft Store MSIX es posible como alternativa, pero no implementado en este ZIP.

Documentación: https://learn.microsoft.com/en-us/windows/desktop/seccrypto/signtool

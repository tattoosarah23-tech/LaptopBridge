# Publicación Microsoft Store — LaptopBridge v1.4

## Comprobación de requisitos

Fuente oficial Microsoft: https://learn.microsoft.com/windows/apps/publish/faq/get-started-with-the-microsoft-store

MSIX enviados por Partner Center **no requieren firma de una CA comercial**: después de la certificación, Microsoft firma para su distribución por Store. No aplica a ZIP, `.exe`, MSI o MSIX descargables por fuera de la Store. Una compilación MSIX sin firma **no debe instalarse por sideload** en Windows 11 protegido por Smart App Control.

## Procedimiento reproducible

**A. Primero validación remota sin identidad:**

1. Crear un repositorio GitHub **privado**, subir el proyecto v1.4 (incluida `.github/workflows/windows-build.yml`).
2. Ejecutar Actions → LaptopBridge Windows + MSIX build (UNSIGNED) → Run workflow con `store_submission=false`.
3. Examinar los logs: 24 pruebas locales, compilación de 2 PE, smoke test MCP en perfil temporal, verificación de estructura, MakeAppx pack y unpack. Si alguna falla, no publicar.
4. El resultado `PREVIEW_UNSIGNED_NOT_INSTALLABLE.msix` tiene identidad falsa deliberada. **No subirlo como app final ni instalarlo.**

**B. Candidato de Store:**

5. Registrar una app en Partner Center y reservar el nombre. Obtener los valores de identidad de paquete EXACTOS: `Identity Name`, `Publisher`, nombre visible de publicador.
6. En GitHub Actions usar `store_submission=true` y especificar esos valores tal cual. No incluir claves ni contraseñas.
7. Obtener el archivo `...STORE_SUBMISSION_UNSIGNED.msix` creado por el runner y cotejar logs de MakeAppx; validar con Windows App Certification Kit en entorno Windows adecuado.
8. Subir el paquete mediante Partner Center, completar declaración de privacidad, contenido, política comercial y certificación de la aplicación.
9. Microsoft puede aprobar, rechazar o solicitar cambios. **No hay garantía de aprobación ni fecha de publicación.**

**C. Instalación final sin bajar protección:**

10. Tras la publicación, instalar LaptopBridge **desde Microsoft Store** con Smart App Control activado, no desde los ZIP/artefactos.
11. Abrir el panel, confirmar que hay cero carpetas autorizadas. Crear/autorizar exclusivamente una carpeta vacía de pruebas.
12. Comprobar consola MCP por alias `laptopbridge-mcp.exe` con cliente que preserve STDIN/STDOUT; las aplicaciones MSIX pueden tener restricciones de activación y hay que verificarlo, no asumir compatibilidad.
13. Probar acceso denegado, escritura, plan de borrado, botón cancelar, confirmación `ELIMINAR`, Papelera y restauración.

## Notas arquitectónicas

- Manifiesto: dos aplicaciones `packagedClassicApp`, `mediumIL`, capacidad `runFullTrust` (no requiere elevación). La segunda no figura en Inicio (`AppListEntry=none`) y expone alias MCP.
- El contenedor MSIX NO es sandbox de archivos: aplicaciones full-trust pueden tener acceso ordinario del usuario. El control restringido depende del código y requiere evaluación de seguridad.
- `LOCALAPPDATA` bajo MSIX puede estar virtualizado; comprueba que panel y MCP comparten el mismo estado y que persiste tras reinicios y actualizaciones.
- Se incluye un script de firma tradicional aparte para distribución no-Store, pero **NO se utiliza ni se requiere para el pipeline de Store**.

## Fuentes técnicas

- https://learn.microsoft.com/windows/apps/publish/faq/get-started-with-the-microsoft-store
- https://learn.microsoft.com/windows/apps/publish/publish-your-app/package-version-numbering
- https://learn.microsoft.com/windows/msix/desktop/desktop-to-uwp-manual-conversion
- https://learn.microsoft.com/windows/apps/desktop/modernize/desktop-to-uwp-extensions
- https://learn.microsoft.com/windows/uwp/packaging/create-app-package-with-makeappx-tool
- https://learn.microsoft.com/windows/msix/desktop/desktop-to-uwp-behind-the-scenes

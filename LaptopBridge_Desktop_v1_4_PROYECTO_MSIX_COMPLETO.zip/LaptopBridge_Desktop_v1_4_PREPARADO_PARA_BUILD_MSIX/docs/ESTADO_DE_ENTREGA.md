# Estado v1.4 — MSIX

- Código local del motor y GUI: incorporado desde v1.2.
- Control de carpetas: validación de aplicación; default-deny.
- Borrado: solo tras solicitud, confirmación en GUI local y respaldo.
- Manifiesto MSIX (dos entry points): preparado.
- Archivos PNG del paquete: preparados.
- Pipeline GitHub Actions Windows PyInstaller + MakeAppx (sin firma): implementado, **no ejecutado desde esta conversación**.
- Pruebas unitarias/estáticas en Linux: ver README para resultado real.
- Compilación EXE sobre Windows: **pendiente**.
- Empaquetado `.msix` real mediante Windows SDK: **pendiente**.
- Firma Microsoft Store, certificación y publicación: **pendientes**.
- Prueba Windows 11 Smart App Control activo: **pendiente**.
- Probar GUI, alias MCP stdio, Papelera y archivo ficticio bajo instalación MSIX: **pendiente**.
- Auditoría de seguridad Windows/TOCTOU antes de distribución comercial: **pendiente**.

Ningún archivo de tu laptop ha sido modificado por esta entrega.

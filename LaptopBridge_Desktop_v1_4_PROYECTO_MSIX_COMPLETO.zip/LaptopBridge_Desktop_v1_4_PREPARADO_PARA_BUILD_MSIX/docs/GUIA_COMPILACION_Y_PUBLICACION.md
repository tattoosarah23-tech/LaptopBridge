# LaptopBridge v1.2 — guía para compilar y publicar sin desactivar Smart App Control

## A. Compilar gratis en un equipo Windows de GitHub

**El resultado es SIN FIRMA y NO se debe abrir en la laptop bloqueada por Smart App Control.**

1. Crea un repositorio **privado** en GitHub para el código LaptopBridge, si todavía no existe. No subas certificados ni claves privadas.
2. Descomprime `LaptopBridge_Desktop_v1_2_Release.zip` en una carpeta local. Sube su contenido al repositorio, **incluida** `.github/workflows/windows-build.yml` (carpeta oculta en algunos exploradores).
3. En GitHub abre **Actions** → **LaptopBridge Windows build (UNSIGNED)** → **Run workflow**.
4. El runner `windows-2022` instala Python 3.13, corre pruebas, compila los dos ejecutables en carpetas separadas y ejecuta una prueba MCP no destructiva con `%LOCALAPPDATA%` temporal.
5. Si termina PASS, en la página del workflow puede aparecer el artefacto `LaptopBridge_v1_2_UNSIGNED_NOT_FOR_INSTALLATION`. **No lo abras/ejecutes en tu laptop.** Este artefacto solo es el insumo de firma.

> Los permisos, cuotas de GitHub Actions y el acceso a repositorios privados están sujetos a la cuenta y a sus límites actuales. No se ha ejecutado aquí un workflow de GitHub.

## B. Firma de confianza: dos rutas

### B1. Distribución directa como ZIP portable firmado

Necesitas un certificado **RSA Code Signing** emitido por una CA reconocida en Microsoft Trusted Root Program o un servicio compatible. Microsoft Artifact Signing puede no estar disponible para todos los países y tipos de cuenta. No uses certificado autofirmado para esta laptop.

En un equipo Windows de publicación donde tengas SignTool, un certificado válido en `Cert:\CurrentUser\My` y el build:

```powershell
.\build\sign-release.ps1 -CertificateThumbprint '40_DIGITOS_HEXADECIMALES_REALES' -TimestampUrl 'https://SERVIDOR_RFC3161_DE_TU_PROVEEDOR'
```

La opción anterior asume clave accesible desde el almacén de certificados de Windows. **No admite directamente Artifact Signing en la nube**; ese servicio exige integrar su propio proveedor de SignTool y credenciales, que no están configurados aquí.

**Nunca envíes tu clave privada, PFX o contraseña al chat ni los incluyas en GitHub.**

El resultado se genera en `.build-windows/release/LaptopBridge_Desktop_1.2_Signed_Windows11.zip` únicamente si los binarios cumplen las verificaciones.

Para inspeccionarlo sin ejecutarlo, usa:

```powershell
.\build\verify-signed-release.ps1 -Folder 'C:\RUTA\LaptopBridge_Desktop_1.2_Signed'
```

### B2. Microsoft Store con paquete MSIX (firma gestionada por Microsoft)

La Store ofrece firma sin coste de certificado para paquetes MSIX que superen la certificación. **Esto NO es equivalente a subir un ZIP o EXE:** faltan el empaquetado MSIX, metadatos de Partner Center, identidad Publisher y validación funcional. No hay instalador MSIX en este paquete. Es una alternativa de publicación por desarrollar si prefieres no comprar un certificado de firma.

## C. Pruebas finales Windows

1. Con Smart App Control **activo**, inspeccionar firmas y hashes.
2. Instalar/extraer la distribución firmada en una carpeta de aplicación.
3. Iniciar `LaptopBridge-Control.exe` sin permisos de administrador.
4. Confirmar `0` raíces autorizadas de inicio.
5. Autorizar solo `%USERPROFILE%\LaptopBridge-Prueba` (carpeta VACÍA fuera de la app y AppData).
6. Conectar `LaptopBridge-MCP.exe` a un cliente MCP local compatible y verificar lectura/creación/edición.
7. Probar rechazo de rutas ajenas y eliminación con confirmación local. Restaurar desde respaldo.
8. Revocar permisos y comprobar que toda operación posterior se deniega.

En caso de bloqueo de Smart App Control: **no lo desactives**. Recoge el mensaje y las firmas, y vuelve a la fase de publicación.

## Documentación oficial

- https://learn.microsoft.com/en-us/windows/apps/package-and-deploy/code-signing-options
- https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions
- https://learn.microsoft.com/en-us/windows/desktop/seccrypto/signtool
- https://pyinstaller.org/en/stable/usage.html

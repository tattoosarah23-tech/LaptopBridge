# Material de presentación Microsoft Store — LaptopBridge v1.4 (borrador)

## Nombre
LaptopBridge

## Descripción breve (ES)
Herramienta local de Windows para operar archivos únicamente en carpetas que el usuario autoriza desde la aplicación, con confirmación presencial antes de eliminarlos.

## Descripción completa (ES)
LaptopBridge proporciona un panel local donde el usuario elige y revoca carpetas de trabajo permitidas. Su servidor MCP por entrada/salida estándar expone herramientas para enumerar, consultar, buscar, crear, editar, copiar, mover y renombrar archivos y carpetas. Antes de eliminar, solicita un plan de operación y requiere una ventana de confirmación local. Se guardan copias para recuperación y un registro técnico de operaciones en almacenamiento local.

La instalación comienza sin ninguna carpeta autorizada. No tiene un servidor público de red y no incluye un ejecutor general de comandos de PowerShell. El acceso autorizado se restringe en el código de la aplicación; no constituye un sandbox garantizado por Windows.

## Justificación para capacidad restringida `runFullTrust`
La aplicación necesita ejecutar un proceso de escritorio clásico (panel de Windows) y un servidor de herramientas MCP `stdio`, así como acceder a operaciones de archivos Win32 bajo el usuario activo. No solicita privilegios de administrador. La capacidad `runFullTrust` sirve para iniciar los procesos de escritorio en nivel de integridad medio; la autorización real de carpetas se gestiona mediante la interfaz local.

## Borrador de privacidad (publicar y revisar antes de enviar)
LaptopBridge guarda en el equipo la lista de carpetas autorizadas, las preferencias, un registro técnico local de operaciones y los respaldos realizados por el motor. El código base no incorpora publicidad, seguimiento analítico ni envío directo de archivos a un servidor del desarrollador.

**Aviso importante:** si el usuario conecta LaptopBridge a un cliente MCP remoto o a un modelo de IA, los contenidos de archivos solicitados por ese cliente **pueden transmitirse a ese proveedor** según sus propios términos y ajustes de privacidad. LaptopBridge no puede garantizar la confidencialidad de la información después de entregarla al cliente MCP.

El titular debe revisar este borrador, definir el responsable del tratamiento y publicar una URL accesible con la política definitiva. No hay una URL de privacidad publicada en el proyecto.

## Información que el titular debe proporcionar al publicar
- Identidad del editor, dominio/contacto de soporte, términos de distribución y URL pública de privacidad.
- Capturas de pantalla REALES tomadas de la aplicación compilada y validada.
- Declaraciones correctas sobre prácticas de datos, uso de la capacidad restringida, clasificación por edades y requisitos de accesibilidad.
- Nombre de paquete y publisher EXACTOS del Partner Center.

**No enviado ni aprobado por Microsoft.** Este documento es texto inicial para revisión humana, no una garantía de cumplimiento de la Store.

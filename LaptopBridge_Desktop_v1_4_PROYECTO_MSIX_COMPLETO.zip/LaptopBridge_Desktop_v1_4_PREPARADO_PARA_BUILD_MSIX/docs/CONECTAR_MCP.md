# Conexión MCP local: LaptopBridge Desktop 1.1

**Primero:** solo usar el release Windows compilado, firmado y verificado según `FIRMA_Y_BUILD.md`. Los archivos `.py` y los scripts de `build/` no son instaladores Windows. No ejecutar binarios sin firma en el equipo protegido.

## Cliente MCP stdio

Después de comprobar firmas y que Smart App Control permite iniciar los ejecutables firmados:

1. Abre `LaptopBridge-Control.exe` y autoriza exclusivamente una carpeta de prueba.
2. En el cliente MCP que **admita el transporte local stdio**, configura `LaptopBridge-MCP.exe` como comando del servidor. El proceso debe ejecutarse bajo la sesión Windows interactiva, no en un servicio desatendido, para mostrar aprobación local de borrado.
3. Usa `roots_list` para obtener ID opacos; prueba `files_list` y escribe un archivo ficticio.
4. Al solicitar eliminación, el motor abre la confirmación local y exige escribir `ELIMINAR`. No es posible aprobar desde otra herramienta MCP.

### Configuración genérica de ejemplo

```json
{
  "mcpServers": {
    "laptopbridge": {
      "command": "C:\\Ruta\\LaptopBridge_Desktop_1.1_Signed\\LaptopBridge-MCP\\LaptopBridge-MCP.exe"
    }
  }
}
```

Esta estructura es **solo un ejemplo de cliente MCP que admita `mcpServers` y stdio**. No confirma que ChatGPT acepte esos campos ni que tu cuenta pueda conectar un servidor local directamente. Este ZIP no incorpora túnel de red, plugin registrado en ChatGPT, ni autenticación remota.

La sesión de ChatGPT web no adquiere acceso a Windows por instalar la app. En su caso sería necesario un mecanismo compatible y permisos específicos, documentados y verificados aparte.

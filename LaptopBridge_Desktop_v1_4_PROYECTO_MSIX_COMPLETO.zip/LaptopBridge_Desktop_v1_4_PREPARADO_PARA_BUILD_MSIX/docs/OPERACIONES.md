# API MCP — Operaciones

Transporte `stdio`: mensajes JSON-RPC 2.0 delimitados por una nueva línea UTF-8. `initialize`, `ping`, `tools/list`, `tools/call`, `notifications/initialized` son reconocidos. El servidor no permite configurar permisos desde MCP.

## Ejemplos conceptuales de tools/call

**Listar las carpetas autorizadas:**

```json
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"roots_list","arguments":{}}}
```

**Leer archivo:**

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"files_read_text","arguments":{"root_id":"<id-del-panel>","relative_path":"src/index.html"}}}
```

**Editar de modo seguro:**

1. `files_read_text` retorna `sha256` del contenido actual.
2. `files_diff` retorna diferencias del texto propuesto (opcional, recomendado).
3. `files_write_text` con `root_id`, `relative_path`, `content`, `overwrite: true`, `expected_sha256` exacto.
4. El agente guarda automáticamente respaldo y retorna `backup_id` para restauración.

**Eliminar** (solo Windows local interactivo):

1. `files_plan_delete(root_id, relative_paths: ["old.txt"])` devuelve `plan_id`.
2. `files_delete(plan_id)` abre ventana **local**. Debes escribir `ELIMINAR`; puede rechazarse o caducar.
3. Se conserva un respaldo automático antes de la operación y luego se solicita trasladar a Papelera. El resultado retorna `backup_ids` de recuperación.
4. `files_restore_snapshot(backup_id)` restaura un archivo ausente o directorio ausente. Si el archivo destino existe exige `expected_current_sha256` del contenido actual. No sobrescribe carpetas existentes.

## Parámetros relevantes

| Herramienta | Parámetros obligatorios |
|---|---|
| roots_list | ninguno |
| files_list | root_id (opcional: relative_path=".", depth=1, limit=100) |
| files_stat | root_id, relative_path |
| files_read_text | root_id, relative_path (opcional max_bytes) |
| files_search | root_id (opcional pattern="*", relative_path=".", limit=50) |
| files_mkdir | root_id, relative_path (padre debe existir) |
| files_write_text | root_id, relative_path, content; para sobrescribir overwrite=true, expected_sha256 |
| files_diff | root_id, relative_path, proposed_content |
| files_copy | src_root_id, src_relative_path, dst_root_id, dst_relative_path |
| files_move | src_root_id, src_relative_path, dst_root_id, dst_relative_path |
| files_rename | root_id, relative_path, new_name |
| files_plan_delete | root_id, relative_paths (lista) |
| files_delete | plan_id |
| files_restore_snapshot | backup_id; y expected_current_sha256 si sobrescribe archivo existente |

Todas las respuestas de herramientas devuelven `ok`, `operation_id`, y cuando fallan, `error_code` y `message`. El contenedor MCP utiliza `isError` para distinguir errores de herramientas. No se admiten operaciones entre discos para mover; copiar sí entre raíces permitidas de discos distintos, sujeto a límites.

Tamaños configurados por defecto: lectura de texto 1 MiB; escritura texto 5 MiB; copia/árbol 500 MiB; máximo 2.000 elementos en árbol; hasta 20 rutas por solicitud de borrado; máximo 200 resultados de búsquedas/listados.

# Prueba final de LaptopBridge MSIX en Windows 11

**No ejecutar scripts `.cmd`, `.ps1`, `.exe` o `.msix` sin firmar en el equipo protegido.** Smart App Control debe permanecer activado. Para distribución Store, esperar a que Microsoft apruebe y firme el paquete y descargarlo solo desde su ficha de Store.

## Pruebas en orden (con carpeta ficticia)

1. Registrar versión de Windows y estado de Smart App Control; instalar desde Store; anotar versión de LaptopBridge.
2. Abrir `LaptopBridge` desde Inicio: debe aparecer el panel, sin elevación, con cero raíces autorizadas.
3. Autorizar carpeta nueva **vacía** `C:\LaptopBridge-Prueba` (si no existe, crearla manualmente). Comprobar que `C:\`, `C:\Windows`, un enlace a otra ruta y la carpeta de instalación están prohibidos.
4. Probar pausa y revocación; el servidor MCP debe denegar peticiones a raíces revocadas.
5. Desde cliente MCP local con stdio, probar `laptopbridge-mcp.exe` y `initialize`, `tools/list` y `roots_list`. Confirmar que tanto panel como MCP comparten las autorizaciones; si no, investigar virtualización de AppData.
6. Crear y leer archivo ficticio UTF-8; editar con SHA-256 esperado; inspeccionar respaldo y SQLite.
7. Crear otro archivo ficticio para eliminación; usar plan + borrado, **Cancelar** en ventana y verificar que sigue existiendo.
8. Repetir con plan nuevo, escribir `ELIMINAR`; verificar envío a Papelera y recuperación desde Papelera o snapshot.
9. Comprobar intentos fuera de carpeta, rutas `..`, junctions, symlinks y archivos duplicados/hardlinks. Ejecutar sobre contenido ficticio.
10. Ejecutar validación del Windows App Certification Kit y revisar que las operaciones permitidas coinciden con lo declarado a Microsoft Store.

## Criterios para cierre

PASS solo tras funcionamiento real del alias MCP en MSIX con pipes, confirmación visible y segura, operación de Papelera, bloqueos de rutas y permiso revocable. La ausencia de alertas de Smart App Control no demuestra por sí sola seguridad. No declarar distribución comercial hasta completar auditoría de seguridad de rutas/TOCTOU.

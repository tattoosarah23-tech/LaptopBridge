"""Static MSIX staging validation; cannot replace Windows SDK MakeAppx/WACK."""
from __future__ import annotations
import argparse
from pathlib import Path
from xml.etree import ElementTree as ET
import struct
import sys

NS = {'m':'http://schemas.microsoft.com/appx/manifest/foundation/windows10',
      'uap':'http://schemas.microsoft.com/appx/manifest/uap/windows10',
      'uap3':'http://schemas.microsoft.com/appx/manifest/uap/windows10/3',
      'desktop':'http://schemas.microsoft.com/appx/manifest/desktop/windows10',
      'rescap':'http://schemas.microsoft.com/appx/manifest/foundation/windows10/restrictedcapabilities'}


def png_size(p: Path):
    data=p.read_bytes()[:24]
    if data[:8] != b'\x89PNG\r\n\x1a\n' or data[12:16] != b'IHDR':
        raise ValueError('PNG inválido: ' + str(p))
    return struct.unpack('>II', data[16:24])


def validate(folder: Path, *, binaries=True):
    folder=folder.resolve()
    manifest=folder/'AppxManifest.xml'
    root=ET.fromstring(manifest.read_bytes())
    identity=root.find('m:Identity', NS)
    assert identity is not None
    assert identity.get('ProcessorArchitecture') == 'x64'
    assert identity.get('Name') and '@' not in identity.get('Name')
    assert identity.get('Publisher','').startswith('CN=')
    assert root.find('m:Capabilities/rescap:Capability',NS).get('Name')=='runFullTrust'
    apps=root.findall('m:Applications/m:Application', NS)
    assert len(apps)==2
    expected={'LaptopBridgeControl': 'Control/LaptopBridge-Control.exe',
              'LaptopBridgeMCP':'MCP/LaptopBridge-MCP.exe'}
    for app in apps:
        assert app.get('Id') in expected
        assert app.get('Executable').replace('\\','/')==expected[app.get('Id')]
        visual=app.find('uap:VisualElements',NS)
        assert visual is not None
        if app.get('Id')=='LaptopBridgeMCP':
            assert visual.get('AppListEntry') == 'none'
            ext=app.find('m:Extensions/uap3:Extension',NS)
            assert ext is not None and ext.get('Category')=='windows.appExecutionAlias'
            alias=ext.find('uap3:AppExecutionAlias/desktop:ExecutionAlias',NS)
            assert alias is not None and alias.get('Alias')=='laptopbridge-mcp.exe'
    sizes={'StoreLogo.png': (50,50), 'Square44x44Logo.png': (44,44),
           'Square150x150Logo.png': (150,150)}
    for name,size in sizes.items():
        assert png_size(folder/'Assets'/name)==size
    if binaries:
        for rel in expected.values():
            p=folder/rel
            assert p.is_file(), f'Falta ejecutable: {p}'
            assert p.open('rb').read(2)==b'MZ', f'No es PE válido: {p}'
        for sub in ('Control','MCP'):
            assert (folder/sub/'_internal').is_dir(), f'Faltan dependencias: {sub}'
    return True


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('staging', type=Path)
    parser.add_argument('--no-binaries',action='store_true')
    args=parser.parse_args()
    validate(args.staging,binaries=not args.no_binaries)
    print('PASS: staging MSIX, manifiesto, identidad, logos y alias coherentes')

if __name__=='__main__':
    main()

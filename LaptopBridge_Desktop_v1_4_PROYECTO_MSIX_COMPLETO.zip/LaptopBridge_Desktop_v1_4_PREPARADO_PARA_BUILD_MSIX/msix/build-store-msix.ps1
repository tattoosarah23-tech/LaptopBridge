# Builds an UNSIGNED MSIX using makeappx; does NOT install, sign, or bypass Smart App Control.
[CmdletBinding(DefaultParameterSetName='Preview')]
param(
  [Parameter(ParameterSetName='Preview', Mandatory=$true)][switch]$Preview,
  [Parameter(ParameterSetName='Store', Mandatory=$true)][switch]$StoreSubmission,
  [Parameter(ParameterSetName='Store', Mandatory=$true)][string]$PackageName,
  [Parameter(ParameterSetName='Store', Mandatory=$true)][string]$Publisher,
  [Parameter(ParameterSetName='Store', Mandatory=$true)][string]$PublisherDisplayName,
  [string]$Version='1.4.0.0',
  [string]$DistRoot='',
  [string]$OutputDirectory='',
  [string]$PythonCommand='python'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Se requiere Windows' }
$project=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $DistRoot) { $DistRoot=Join-Path $project '.build-windows\dist' }
if (-not $OutputDirectory) { $OutputDirectory=Join-Path $project '.build-windows\msix' }
if ($Preview) {
  $PackageName='LaptopBridge.Development'
  $Publisher='CN=LaptopBridgeDevelopment'
  $PublisherDisplayName='LaptopBridge Development'
  $tag='PREVIEW_UNSIGNED_NOT_INSTALLABLE'
} else {
  if ([string]::IsNullOrWhiteSpace($PackageName) -or
      [string]::IsNullOrWhiteSpace($Publisher) -or
      [string]::IsNullOrWhiteSpace($PublisherDisplayName)) { throw 'Identidad real de Partner Center obligatoria' }
  $tag='STORE_SUBMISSION_UNSIGNED'
}
$ctrl=Join-Path $DistRoot 'LaptopBridge-Control'
$mcp=Join-Path $DistRoot 'LaptopBridge-MCP'
foreach ($dir in @($ctrl,$mcp)) { if (-not (Test-Path -LiteralPath $dir -PathType Container)) { throw "No existe $dir. Primero compila los ejecutables en Windows." } }
$stage=Join-Path $OutputDirectory 'staging'
if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage,(Join-Path $stage 'Control'),(Join-Path $stage 'MCP'),(Join-Path $stage 'Assets') -Force | Out-Null
foreach ($item in (Get-ChildItem -LiteralPath $ctrl -Force)) { Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $stage 'Control') -Recurse -Force }
foreach ($item in (Get-ChildItem -LiteralPath $mcp -Force)) { Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $stage 'MCP') -Recurse -Force }
Copy-Item -Path (Join-Path $PSScriptRoot 'assets\*.png') -Destination (Join-Path $stage 'Assets') -Force
$render=@((Join-Path $PSScriptRoot 'render_manifest.py'), '--template', (Join-Path $PSScriptRoot 'AppxManifest.xml.in'), '--output', (Join-Path $stage 'AppxManifest.xml'), '--package-name', $PackageName, '--publisher', $Publisher, '--publisher-display-name', $PublisherDisplayName, '--version', $Version)
if ($Preview) { $render += '--preview' }
& $PythonCommand @render
if ($LASTEXITCODE -ne 0) { throw 'Render de manifiesto fallido' }
& $PythonCommand (Join-Path $PSScriptRoot 'validate_layout.py') $stage
if ($LASTEXITCODE -ne 0) { throw 'Validación de staging fallida' }
$makeappx=Get-ChildItem -Path "${env:ProgramFiles(x86)}\Windows Kits\10\bin" -Filter 'makeappx.exe' -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match '\\x64\\makeappx.exe$' } | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $makeappx) { throw 'MakeAppx.exe x64 no encontrado: instala Windows SDK en el runner de build' }
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$destination=Join-Path $OutputDirectory ("LaptopBridge_{0}_x64_{1}.msix" -f $Version,$tag)
if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Force }
& $makeappx.FullName pack /d $stage /p $destination /o
if ($LASTEXITCODE -ne 0) { throw 'MakeAppx falló: manifiesto/paquete no válido' }
# A second unpack detects damaged payloads; pack itself performs semantic validation.
$unpacked=Join-Path $OutputDirectory 'roundtrip-validation'
if (Test-Path -LiteralPath $unpacked) { Remove-Item -LiteralPath $unpacked -Recurse -Force }
& $makeappx.FullName unpack /p $destination /d $unpacked /o
if ($LASTEXITCODE -ne 0) { throw 'No se pudo extraer el MSIX para verificarlo' }
& $PythonCommand (Join-Path $PSScriptRoot 'validate_layout.py') $unpacked
if ($LASTEXITCODE -ne 0) { throw 'Roundtrip MSIX falló' }
$hash=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
Write-Host "MSIX empaquetado correctamente: $destination"
Write-Host "SHA256=$hash"
Write-Host 'PAQUETE SIN FIRMAR: NO INSTALAR EN WINDOWS PROTEGIDO.'
Write-Host 'Si es STORE_SUBMISSION: requiere certificación y firma de Microsoft Store.'

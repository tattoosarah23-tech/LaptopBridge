"""Render the MSIX manifest using Partner Center package identity, no secrets."""
from __future__ import annotations
import argparse
import re
from pathlib import Path
from xml.etree import ElementTree
from xml.sax.saxutils import escape

PLACEHOLDERS = ('PACKAGE_NAME', 'PUBLISHER', 'PUBLISHER_DISPLAY_NAME', 'VERSION')


def render(template: str, *, package_name: str, publisher: str,
           publisher_display_name: str, version: str, preview: bool = False) -> str:
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]{1,49}', package_name):
        raise ValueError('Package Name inválido; usa exactamente el de Partner Center')
    if not re.fullmatch(r'(?:[0-9]+\.){3}[0-9]+', version):
        raise ValueError('Versión debe contener cuatro números, ejemplo 1.4.0.0')
    numbers = [int(v) for v in version.split('.')]
    if any(n < 0 or n > 65535 for n in numbers) or numbers[-1] != 0:
        raise ValueError('Versión MSIX inválida; el cuarto componente debe ser 0')
    if not publisher.startswith('CN=') or '\x00' in publisher or len(publisher) > 1024:
        raise ValueError('Publisher debe venir exactamente de Partner Center (normalmente comienza CN=)')
    if not publisher_display_name.strip() or len(publisher_display_name) > 256:
        raise ValueError('Nombre del editor inválido')
    if not preview and ('Development' in publisher or 'example' in package_name.lower()
                        or publisher_display_name.lower() in ('dev', 'development')):
        raise ValueError('La identidad de desarrollo no se puede usar como publicación')
    vals = dict(PACKAGE_NAME=package_name, PUBLISHER=publisher,
                PUBLISHER_DISPLAY_NAME=publisher_display_name, VERSION=version)
    rendered = template
    for name in PLACEHOLDERS:
        rendered = rendered.replace('@' + name + '@', escape(vals[name], {'"': '&quot;'}))
    if re.search(r'@[A-Z_]+@', rendered):
        raise ValueError('Quedan campos sin configurar')
    ElementTree.fromstring(rendered)
    return rendered


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--template', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--package-name', required=True)
    parser.add_argument('--publisher', required=True)
    parser.add_argument('--publisher-display-name', required=True)
    parser.add_argument('--version', default='1.4.0.0')
    parser.add_argument('--preview', action='store_true')
    args = parser.parse_args()
    contents = render(args.template.read_text(encoding='utf-8'),
                      package_name=args.package_name, publisher=args.publisher,
                      publisher_display_name=args.publisher_display_name,
                      version=args.version, preview=args.preview)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(contents, encoding='utf-8')
    print('Manifest generado:', args.output)


if __name__ == '__main__':
    main()

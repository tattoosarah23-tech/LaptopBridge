"""End-to-end JSON-RPC over a real stdio process in an isolated profile."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class IsolatedMCPProcessTests(unittest.TestCase):
    def test_process_starts_without_permissions_or_mutations(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = os.environ.copy()
            env['HOME'] = tmp
            env['USERPROFILE'] = tmp
            if os.name == 'nt':
                env['LOCALAPPDATA'] = str(Path(tmp)/'Local')
            env['PYTHONPATH'] = str(Path(__file__).resolve().parents[1]/'src')
            messages = [
                {'jsonrpc':'2.0', 'id':1, 'method':'initialize', 'params':{'protocolVersion':'2025-06-18'}},
                {'jsonrpc':'2.0', 'id':2, 'method':'tools/list'},
                {'jsonrpc':'2.0', 'id':3, 'method':'tools/call', 'params':{'name':'roots_list','arguments':{}}},
                {'jsonrpc':'2.0', 'id':4, 'method':'tools/call', 'params':{'name':'files_list', 'arguments':{'root_id':'f'*32}}},
            ]
            proc = subprocess.run([sys.executable,'-m','laptopbridge','mcp'],
                input=''.join(json.dumps(m)+'\n' for m in messages),
                text=True,capture_output=True,timeout=15,env=env)
            self.assertEqual(proc.returncode,0,proc.stderr)
            replies=[json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
            self.assertEqual([x['id'] for x in replies],[1,2,3,4])
            self.assertEqual(replies[0]['result']['serverInfo']['version'],'1.4.0')
            self.assertEqual(len(replies[1]['result']['tools']),14)
            roots=json.loads(replies[2]['result']['content'][0]['text'])
            self.assertEqual(roots['data']['roots'],[])
            denied=json.loads(replies[3]['result']['content'][0]['text'])
            self.assertEqual(denied['error_code'],'ACCESS_DENIED')
            self.assertFalse(denied['ok'])


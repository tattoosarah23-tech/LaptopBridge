import hashlib
import io
import json
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from laptopbridge.config import State
from laptopbridge.core import Bridge
from laptopbridge.errors import BridgeError
from laptopbridge.mcp_stdio import dispatch, run_stdio, TOOLS


class LaptopBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        p = Path(self.temp.name)
        self.source = p / 'permitted'
        self.target = p / 'permitted2'
        self.outside = p / 'private'
        for folder in (self.source, self.target, self.outside):
            folder.mkdir()
        self.state = State(p / 'agent_data')
        self.state_id = self.state.add_root(self.source, 'Trabajo')['id']
        self.dest_id = self.state.add_root(self.target, 'Destino')['id']
        self.bridge = Bridge(self.state, approval=lambda entries, ttl: False,
                             recycle=lambda path: path.unlink())

    def call(self, name, **kwargs):
        return self.bridge.invoke(name, kwargs)

    def check(self, name, **kwargs):
        r = self.call(name, **kwargs)
        self.assertTrue(r['ok'], r)
        return r['data']

    def test_default_deny_and_no_remote_permission_tools(self):
        fresh = Bridge(State(Path(self.temp.name) / 'empty_agent'))
        self.assertEqual(fresh.list_roots()['roots'], [])
        result = fresh.invoke('files_list', {'root_id': 'f' * 32})
        self.assertEqual(result['error_code'], 'ACCESS_DENIED')
        self.assertNotIn('grant_root', [tool['name'] for tool in TOOLS])
        self.assertFalse(fresh.invoke('execute_powershell', {})['ok'])

    def test_path_traversal_and_windows_special_paths(self):
        for path in ('../private/secret.txt', 'folder/../../private', '/etc/passwd',
                     'C:\\Windows\\win.ini', '\\\\server\\share', 'a//b', 'x/./y',
                     'x:secret', 'CON.txt', 'a. ', 'folder/NUL', 'a\\..\\b'):
            with self.subTest(path=path):
                result = self.call('files_read_text', root_id=self.state_id,
                                   relative_path=path)
                self.assertFalse(result['ok'], result)

    def test_symlink_escape_denied(self):
        (self.outside / 'private.txt').write_text('secret')
        link = self.source / 'outside_link'
        try:
            link.symlink_to(self.outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('Symlinks require privileges on this system')
        self.assertEqual(self.call('files_read_text', root_id=self.state_id,
                                   relative_path='outside_link/private.txt')['error_code'],
                         'REPARSE_POINT_DENIED')
        results = self.check('files_list', root_id=self.state_id)['entries']
        self.assertTrue(any(x['kind'] == 'blocked_link' for x in results))

    def test_root_overlaps_rejected(self):
        with self.assertRaises(BridgeError):
            self.state.add_root(self.source)
        with self.assertRaises(BridgeError):
            self.state.add_root(Path(self.temp.name))

    def test_write_diff_backup_restore(self):
        init = self.check('files_write_text', root_id=self.state_id,
                          relative_path='index.html', content='old\n')
        self.assertIsNone(init['backup_id'])
        diff = self.check('files_diff', root_id=self.state_id,
                          relative_path='index.html', proposed_content='new\n')
        self.assertIn('-old', diff['diff'])
        self.assertIn('+new', diff['diff'])
        conflict = self.call('files_write_text', root_id=self.state_id,
                             relative_path='index.html', content='oops', overwrite=True,
                             expected_sha256='wrong')
        self.assertEqual(conflict['error_code'], 'CONFLICT')
        output = self.check('files_write_text', root_id=self.state_id,
                            relative_path='index.html', content='new\n', overwrite=True,
                            expected_sha256=diff['expected_sha256'])
        self.assertTrue(output['backup_id'])
        self.assertEqual((self.source / 'index.html').read_text(), 'new\n')
        restored = self.check('files_restore_snapshot', backup_id=output['backup_id'],
                              expected_current_sha256=output['sha256'])
        self.assertEqual((self.source / 'index.html').read_text(), 'old\n')
        self.assertEqual(restored['sha256'], init['sha256'])
        self.assertTrue(self.state.backups.joinpath(output['backup_id'] + '.bin').exists())

    def test_directory_creation_listing_copy_move_and_search(self):
        self.check('files_mkdir', root_id=self.state_id, relative_path='src')
        self.check('files_write_text', root_id=self.state_id,
                   relative_path='src/app.py', content='print(1)\n')
        self.check('files_write_text', root_id=self.state_id,
                   relative_path='src/readme.txt', content='hello')
        self.check('files_copy', src_root_id=self.state_id, src_relative_path='src',
                   dst_root_id=self.dest_id, dst_relative_path='src_clone')
        self.assertEqual((self.target / 'src_clone' / 'app.py').read_text(), 'print(1)\n')
        result = self.check('files_search', root_id=self.dest_id,
                            pattern='*.py', relative_path='.')
        self.assertEqual(result['matches'], ['src_clone/app.py'])
        self.check('files_rename', root_id=self.dest_id, relative_path='src_clone/app.py',
                   new_name='main.py')
        self.assertTrue((self.target / 'src_clone' / 'main.py').exists())
        self.check('files_move', src_root_id=self.dest_id, src_relative_path='src_clone',
                   dst_root_id=self.dest_id, dst_relative_path='renamed')
        self.assertTrue((self.target / 'renamed' / 'main.py').exists())
        self.assertEqual(self.check('files_stat', root_id=self.dest_id,
                                    relative_path='renamed/main.py')['kind'], 'file')
        self.assertTrue(len(self.check('files_list', root_id=self.dest_id,
                                       relative_path='.', depth=3)['entries']) >= 3)

    def test_delete_denied_then_approved_once_with_test_double(self):
        self.check('files_write_text', root_id=self.state_id,
                   relative_path='old.txt', content='erase')
        plan = self.check('files_plan_delete', root_id=self.state_id,
                          relative_paths=['old.txt'])
        result = self.call('files_delete', plan_id=plan['plan_id'])
        self.assertEqual(result['error_code'], 'APPROVAL_DENIED')
        self.assertTrue((self.source / 'old.txt').exists())
        self.bridge.approval = lambda entries, ttl: True
        plan2 = self.check('files_plan_delete', root_id=self.state_id,
                           relative_paths=['old.txt'])
        self.check('files_delete', plan_id=plan2['plan_id'])
        self.assertFalse((self.source / 'old.txt').exists())
        self.assertFalse(self.call('files_delete', plan_id=plan2['plan_id'])['ok'])

    def test_delete_directory_restore_with_mock_recycle(self):
        directory = self.source / 'obsolete'
        directory.mkdir()
        (directory / 'data.txt').write_text('keep in archive')
        self.bridge.approval = lambda entries, ttl: True
        self.bridge.recycle = lambda path: shutil.rmtree(path)
        plan = self.check('files_plan_delete', root_id=self.state_id,
                          relative_paths=['obsolete'])
        deleted = self.check('files_delete', plan_id=plan['plan_id'])
        self.assertFalse(directory.exists())
        self.assertEqual(len(deleted['backup_ids']), 1)
        recovered = self.check('files_restore_snapshot', backup_id=deleted['backup_ids'][0])
        self.assertEqual(recovered['backup_kind'], 'directory')
        self.assertEqual((directory / 'data.txt').read_text(), 'keep in archive')

    def test_replaced_root_identity_denied(self):
        renamed = Path(self.temp.name) / 'old_permitted'
        self.source.rename(renamed)
        self.source.mkdir()
        result = self.call('files_list', root_id=self.state_id)
        self.assertEqual(result['error_code'], 'STALE_ROOT')

    def test_delete_stale_content_and_expired_plan_denied(self):
        p = self.source / 'old.txt'
        p.write_text('abc')
        planned = self.check('files_plan_delete', root_id=self.state_id,
                             relative_paths=['old.txt'])
        p.write_text('changed')
        self.assertEqual(self.call('files_delete', plan_id=planned['plan_id'])['error_code'],
                         'STALE_TARGET')
        plan2 = self.check('files_plan_delete', root_id=self.state_id,
                           relative_paths=['old.txt'])
        self.bridge.plans[plan2['plan_id']]['expires'] = time.monotonic() - 1
        self.assertEqual(self.call('files_delete', plan_id=plan2['plan_id'])['error_code'],
                         'APPROVAL_EXPIRED')
        self.assertTrue(p.exists())

    def test_root_pausing_revoking_take_effect(self):
        self.state.set_pause(True)
        self.assertEqual(self.call('files_list', root_id=self.state_id)['error_code'], 'PAUSED')
        self.state.set_pause(False)
        self.state.remove_root(self.state_id)
        self.assertEqual(self.call('files_list', root_id=self.state_id)['error_code'],
                         'ACCESS_DENIED')

    def test_mcp_protocol(self):
        response = dispatch(self.bridge, {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize',
                                          'params': {'protocolVersion': '2025-06-18'}})
        self.assertEqual(response['result']['serverInfo']['name'], 'LaptopBridge')
        tools = dispatch(self.bridge, {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'})
        self.assertIn('files_delete', [t['name'] for t in tools['result']['tools']])
        tool_call = dispatch(self.bridge, {'jsonrpc': '2.0', 'id': 3,
                                           'method': 'tools/call',
                                           'params': {'name': 'roots_list', 'arguments': {}}})
        self.assertFalse(tool_call['result']['isError'])
        inp = io.BytesIO((json.dumps({'jsonrpc':'2.0', 'id':4, 'method':'ping'})+'\n').encode())
        out = io.BytesIO()
        run_stdio(self.bridge, inp, out)
        self.assertEqual(json.loads(out.getvalue())['result'], {})


if __name__ == '__main__':
    unittest.main()

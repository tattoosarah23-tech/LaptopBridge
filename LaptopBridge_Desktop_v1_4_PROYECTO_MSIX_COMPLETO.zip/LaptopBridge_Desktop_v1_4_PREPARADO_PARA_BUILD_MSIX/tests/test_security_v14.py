"""Regression tests for bounded content verification and hardlink exclusion."""
import os
import tempfile
from pathlib import Path
from unittest import TestCase, mock

from laptopbridge.config import State
from laptopbridge.core import Bridge


class HardenedCopyTests(TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        base = Path(self.temp.name)
        self.src = base / 'src'
        self.dst = base / 'dst'
        self.src.mkdir()
        self.dst.mkdir()
        self.state = State(base / 'state')
        self.src_id = self.state.add_root(self.src)['id']
        self.dst_id = self.state.add_root(self.dst)['id']
        self.bridge = Bridge(self.state, approval=lambda *_: False)

    def test_content_integrity_is_reported(self):
        (self.src / 'hello.txt').write_text('content-123', encoding='utf-8')
        result = self.bridge.invoke('files_copy', dict(src_root_id=self.src_id,
            src_relative_path='hello.txt', dst_root_id=self.dst_id, dst_relative_path='hello.txt'))
        self.assertTrue(result['ok'], result)
        self.assertEqual(len(result['data']['content_sha256']), 64)
        self.assertEqual((self.dst / 'hello.txt').read_text(), 'content-123')

    def test_same_length_corruption_is_denied(self):
        import laptopbridge.core as core
        (self.src / 'hello.txt').write_text('content-123', encoding='utf-8')
        original = core.shutil.copyfileobj
        def corrupt_copy(src, dest, *args, **kwargs):
            original(src, dest, *args, **kwargs)
            dest.flush()
            dest.seek(0)
            dest.write(b'content-456')
            dest.flush()
        with mock.patch('laptopbridge.core.shutil.copyfileobj', side_effect=corrupt_copy):
            result = self.bridge.invoke('files_copy', dict(src_root_id=self.src_id,
                src_relative_path='hello.txt', dst_root_id=self.dst_id, dst_relative_path='hello.txt'))
        self.assertFalse(result['ok'], result)
        self.assertEqual(result['error_code'], 'STALE_TARGET')

    def test_read_and_copy_reject_hardlinks(self):
        outside = Path(self.temp.name) / 'private.txt'
        outside.write_text('not-public', encoding='utf-8')
        try:
            os.link(outside, self.src / 'linked.txt')
        except (OSError, NotImplementedError):
            self.skipTest('Hardlink unsupported by current filesystem')
        for op, args in [
            ('files_read_text', dict(root_id=self.src_id, relative_path='linked.txt')),
            ('files_stat', dict(root_id=self.src_id, relative_path='linked.txt')),
            ('files_copy', dict(src_root_id=self.src_id, src_relative_path='linked.txt',
                                dst_root_id=self.dst_id, dst_relative_path='copied.txt'))]:
            with self.subTest(op=op):
                result = self.bridge.invoke(op, args)
                self.assertEqual(result.get('error_code'), 'HARDLINK_DENIED', result)

    def test_operations_start_with_no_root_permissions(self):
        state = State(Path(self.temp.name) / 'empty-state')
        bridge = Bridge(state)
        self.assertEqual(bridge.list_roots()['roots'], [])
        self.assertEqual(bridge.invoke('files_list', {'root_id': 'a'*32})['error_code'], 'ACCESS_DENIED')

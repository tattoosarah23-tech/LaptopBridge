"""Static MSIX checks runnable on Linux, without Windows SDK."""
from pathlib import Path
import importlib.util
import tempfile
import unittest
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parents[1]


def getmod(name):
    spec=importlib.util.spec_from_file_location(name, BASE/'msix'/f'{name}.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class MSIXTests(unittest.TestCase):
    def setUp(self):
        self.render=getmod('render_manifest')
        self.validate=getmod('validate_layout')
        self.source=(BASE/'msix/AppxManifest.xml.in').read_text(encoding='utf-8')
        self.values={'package_name':'Contoso.LaptopBridge', 'publisher':'CN=1234abcd',
                     'publisher_display_name':'Contoso & Partners', 'version':'1.4.0.0'}

    def test_template_is_valid_xml_after_render(self):
        xml=self.render.render(self.source, **self.values)
        root=ET.fromstring(xml)
        self.assertEqual(root.tag.split('}')[-1], 'Package')
        self.assertIn('&amp;',xml)

    def test_reject_development_publisher_for_store(self):
        with self.assertRaises(ValueError):
            self.render.render(self.source,package_name='Contoso.LaptopBridge',
                               publisher='CN=LaptopBridgeDevelopment',
                               publisher_display_name='Development',version='1.4.0.0')

    def test_reject_bad_version(self):
        with self.assertRaises(ValueError):
            self.render.render(self.source,**(self.values | {'version':'1.4.0.1'}))

    def test_alias_and_logos_exist(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'Assets').mkdir()
            xml=self.render.render(self.source,**self.values)
            (root/'AppxManifest.xml').write_text(xml,encoding='utf-8')
            for p in (BASE/'msix/assets').glob('*.png'):
                (root/'Assets'/p.name).write_bytes(p.read_bytes())
            self.assertTrue(self.validate.validate(root,binaries=False))

    def test_no_alternative_shell_or_unrestricted_filesystem_capability(self):
        self.assertNotIn('broadFileSystemAccess',self.source)
        self.assertNotIn('runAsAdministrator',self.source)
        self.assertNotIn('powershell.exe',self.source.lower())


if __name__=='__main__':
    unittest.main()

"""Static assertions for distribution safety. Windows builds are tested in CI separately."""
import ast
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class ReleasePipelineTests(unittest.TestCase):
    def test_gui_is_not_admin_and_manifest_version_is_updated(self):
        manifest = (ROOT/'build'/'LaptopBridge.manifest').read_text(encoding='utf8')
        self.assertIn('requestedExecutionLevel level="asInvoker"',manifest)
        self.assertIn('1.4.0.0',manifest)
        self.assertNotIn('requireAdministrator',manifest)

    def test_unsigned_artifacts_are_explicitly_labelled(self):
        ci=(ROOT/'.github'/'workflows'/'windows-build.yml').read_text(encoding='utf8')
        self.assertIn('workflow_dispatch:',ci)
        self.assertIn('UNSIGNED_BINARIES_NOT_FOR_INSTALLATION',ci)
        self.assertIn('windows-2022',ci)
        self.assertIn('smoke_mcp_windows.py',ci)
        self.assertNotIn('CertificateThumbprint',ci)

    def test_release_requires_trusted_signatures_and_digest_verification(self):
        sign=(ROOT/'build'/'sign-release.ps1').read_text(encoding='utf8')
        verify=(ROOT/'build'/'verify-signed-release.ps1').read_text(encoding='utf8')
        for requirement in ('Get-AuthenticodeSignature', 'SHA256', 'PUBLISHER.json', 'signtool', 'inventory-pe.ps1'):
            self.assertIn(requirement, sign.lower() if requirement=='signtool' else sign)
        for requirement in ('SHA256.json','PUBLISHER.json','Get-FileHash','Get-AuthenticodeSignature','inventory-pe.ps1'):
            self.assertIn(requirement,verify)

    def test_smoke_test_never_performs_mutation(self):
        path=ROOT/'scripts'/'smoke_mcp_windows.py'
        tree=ast.parse(path.read_text(encoding='utf8'))
        self.assertFalse(any(isinstance(node,ast.Constant) and isinstance(node.value,str) and
                             node.value in ('files_delete','files_write_text','files_mkdir','files_move')
                             for node in ast.walk(tree)))
        self.assertIn("'LOCALAPPDATA'",path.read_text(encoding='utf8'))


if __name__=='__main__':
    unittest.main()

"""Distribution regressions; does not touch user folders."""
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from laptopbridge.config import State
from laptopbridge.core import Bridge
from laptopbridge.errors import BridgeError
from laptopbridge import paths


class DesktopDistributionTests(unittest.TestCase):
    def test_packaged_binary_location_cannot_be_granted(self):
        with tempfile.TemporaryDirectory() as d:
            home = Path(d)/'state'
            install = Path(d)/'install'
            home.mkdir()
            install.mkdir()
            binary = install/'LaptopBridge-Control.exe'
            binary.touch()
            with patch.object(paths.sys, 'frozen', True, create=True), \
                 patch.object(paths.sys, 'executable', str(binary)):
                with self.assertRaises(BridgeError) as cm:
                    paths.verify_root(install, home)
            self.assertEqual(cm.exception.code, 'INVALID_ROOT')

    def test_local_confirmation_displays_complete_filename_and_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            state = State(base/'state')
            root = base/'allowed'
            root.mkdir()
            grant = state.add_root(root)
            target = root/'remove-me.txt'
            target.write_text('sample', encoding='utf-8')
            prompts = []
            def local_confirm(labels, seconds):
                prompts.extend(labels)
                return False
            bridge = Bridge(state, approval=local_confirm)
            plan = bridge.invoke('files_plan_delete', {'root_id':grant['id'], 'relative_paths':['remove-me.txt']})
            self.assertTrue(plan['ok'])
            response = bridge.invoke('files_delete', {'plan_id':plan['data']['plan_id']})
            self.assertFalse(response['ok'])
            self.assertEqual(response['error_code'], 'APPROVAL_DENIED')
            self.assertTrue(target.exists())
            self.assertEqual(len(prompts),1)
            self.assertIn(str(target),prompts[0])

    def test_invalid_grant_does_not_become_accessible_remotely(self):
        with tempfile.TemporaryDirectory() as d:
            bridge = Bridge(State(Path(d)/'state'))
            names = set(bridge.state.read().keys())
            self.assertIn('roots', names)
            self.assertEqual(bridge.invoke('files_list', {'root_id':'a'*32})['error_code'],'ACCESS_DENIED')


if __name__ == '__main__':
    unittest.main()

# LaptopBridge Desktop v1.4 — Pipeline MSIX para Microsoft Store

**Estado:** Código y manifiesto MSIX preparados para compilar en Windows. **NO contiene `.exe` ni `.msix` compilados, firmados o publicados.** No se ejecutó Smart App Control en este entorno ni se conectó ChatGPT.

## Resultado y limitaciones verificadas

- El proyecto incluye el código fuente, pruebas, manifiesto y pipeline de empaquetado. **No se ha generado ni firmado ningún `.exe` o `.msix` en esta entrega.**
- No hay repositorio de LaptopBridge en la conexión GitHub disponible y la integración no incluye creación de repositorios ni lanzamiento de workflows, por lo que no se ha ejecutado GitHub Actions.
- La Store requiere una cuenta de desarrollador, identidad de paquete y presentación aceptada; la aprobación de Microsoft no puede delegarse ni presumirse.
- **Smart App Control debe permanecer activado.** No ejecutar los `.cmd` originales bloqueados ni intentar instalar MSIX sin firmar.

## Qué es

Una aplicación local para Windows 11 con panel de permisos y servidor MCP por `stdio`. Las operaciones con archivos se limitan mediante validaciones de aplicación a carpetas elegidas localmente; esta política **no es un aislamiento del sistema operativo**. No hay comandos arbitrarios de PowerShell ni herramientas MCP para conceder acceso. El borrado requiere plan previo y ventana de confirmación local con `ELIMINAR`, respaldo y traslado a Papelera sin fallback a borrado permanente.

## Carpetas principales

- `src/laptopbridge/`: motor, permisos, registro SQLite, backups, confirmación y Papelera.
- `apps/`: dos puntos de entrada independientes para Windows.
- `build/`: compilación PyInstaller Windows y ruta alternativa de firma directa.
- `msix/AppxManifest.xml.in`: identidad de paquete y dos aplicaciones full-trust (panel + MCP), con alias `laptopbridge-mcp.exe`.
- `msix/assets/`: logos PNG incluidos en el paquete.
- `msix/render_manifest.py`, `msix/validate_layout.py`: render y controles estáticos.
- `msix/build-store-msix.ps1`: crea MSIX **sin firma** mediante el SDK de Windows.
- `.github/workflows/windows-build.yml`: compilación manual en GitHub Actions Windows (con o sin identidad de Partner Center) y subida de artefactos sin firma.
- `docs/PUBLICACION_STORE_MSIX.md`: proceso de publicación y pasos que debe seguir el propietario.
- `docs/VALIDACION_WINDOWS11.md`: validación del sistema final.

## Compilación en GitHub Actions, sin ejecutar el proyecto en tu laptop protegida

1. Sube **el contenido** de este ZIP a un repositorio privado de GitHub, conservando `.github/workflows/windows-build.yml`.
2. En GitHub abre **Actions → LaptopBridge Windows + MSIX build (UNSIGNED) → Run workflow**.
3. Primera ejecución: `store_submission=false`. Compila y valida un MSIX de **preview con identidad provisional**, estrictamente NO instalable.
4. Al tener una aplicación registrada en **Partner Center**, ejecuta otra vez con `store_submission=true` e introduce exactamente `Package/Identity/Name`, `Package/Identity/Publisher` y `PublisherDisplayName` del panel de Microsoft.
5. Descarga el artefacto `LaptopBridge_v1_4_MSIX_UNSIGNED_NOT_FOR_SIDELOAD`; el candidato de Store puede subirse a Partner Center para certificación, pero **no instalarse directamente** mientras no tenga firma de confianza.

**No incluyas contraseñas, certificados, claves privadas ni tokens en el repositorio.** El pipeline no los necesita para envío MSIX a Store. No desactives Smart App Control.

## Verificaciones locales de código (no requiere Windows)

```shell
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Bloqueos pendientes para finalizar una versión instalable

- Compilar los dos ejecutables en un runner Windows real, producir MSIX con MakeAppx y revisar los resultados del CI.
- Verificar funcionamiento bajo identidad MSIX: panel gráfico, alias MCP y transporte `stdio`; las pruebas CI de binarios fuera del MSIX no sustituyen a esta verificación.
- Ejecutar Windows App Certification Kit y pasar revisión de Microsoft Store.
- Disponer de cuenta Partner Center y los valores EXACTOS de identidad registrados para esa app.
- Instalar **desde Microsoft Store** la versión aprobada y validar Smart App Control activado, confirmación local de eliminación, Papelera, lectura/escritura y recuperación con una carpeta de pruebas vacía.
- Validación de seguridad reforzada ante carreras de rutas y archivos modificados concurrentemente; el control a nivel aplicación no ofrece garantía de confinamiento NTFS.

La aprobación de Microsoft Store y la integración concreta en ChatGPT requieren acciones externas del titular; **no se han realizado ni se presumen**.

## Documentos para la fase de publicación

- `docs/FINALIZACION_REAL_WINDOWS11.md`: proceso reproducible, sin desactivar Smart App Control.
- `docs/FICHA_STORE_Y_PRIVACIDAD.md`: texto propuesto para ficha, justificación de `runFullTrust` y borrador de privacidad que debe revisarse y publicarse antes de certificar.

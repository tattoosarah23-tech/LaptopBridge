"""Windows MCP stdio entry point. Must keep stdin/stdout as pipes."""
from laptopbridge.mcp_stdio import run_stdio

if __name__ == '__main__':
    run_stdio()

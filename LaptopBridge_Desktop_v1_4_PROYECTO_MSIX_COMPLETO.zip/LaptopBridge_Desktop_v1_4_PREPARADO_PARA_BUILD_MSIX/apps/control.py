"""Windows GUI entry point. Windows build: PyInstaller --windowed --onedir."""
from laptopbridge.gui import launch

if __name__ == '__main__':
    launch()

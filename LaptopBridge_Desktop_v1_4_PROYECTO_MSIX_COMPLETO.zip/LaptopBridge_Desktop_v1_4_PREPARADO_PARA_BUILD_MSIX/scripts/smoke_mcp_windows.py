"""Windows CI read-only smoke-test of frozen stdio executable.

Uses an isolated temporary LOCALAPPDATA with zero authorized folders.
Only tests initialize, tools/list and default-deny, never writes user files.
"""
import json
import os
import pathlib
import subprocess
import sys
import tempfile


def main():
    if sys.platform != 'win32':
        raise SystemExit('This smoke test requires Windows')
    if len(sys.argv) != 2:
        raise SystemExit('Usage: smoke_mcp_windows.py <path-to-LaptopBridge-MCP.exe>')
    exe = pathlib.Path(sys.argv[1]).resolve(strict=True)
    if exe.name != 'LaptopBridge-MCP.exe':
        raise SystemExit('Incorrect executable; refusing to launch')

    req = [
        {'jsonrpc':'2.0','id':1,'method':'initialize',
         'params':{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'ci-smoke','version':'1'}}},
        {'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}},
        {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'roots_list','arguments':{}}},
        {'jsonrpc':'2.0','id':4,'method':'tools/call','params':{'name':'files_list','arguments':{'root_id':'0'*32}}},
    ]
    with tempfile.TemporaryDirectory(prefix='LaptopBridge-smoke-') as d:
        env=os.environ.copy()
        env['LOCALAPPDATA']=str(pathlib.Path(d)/'AppData')
        env['APPDATA']=str(pathlib.Path(d)/'Roaming')
        lines=''.join(json.dumps(x)+'\n' for x in req)
        run=subprocess.run([str(exe)],input=lines,text=True,capture_output=True,timeout=30,env=env)
        if run.returncode != 0:
            raise RuntimeError(f'MCP binary exit={run.returncode}: {run.stderr[-1000:]}')
        responses=[json.loads(line) for line in run.stdout.splitlines() if line.strip()]
        if [x.get('id') for x in responses] != [1,2,3,4]:
            raise AssertionError('Invalid MCP response IDs')
        tools=responses[1]['result']['tools']
        names={t['name'] for t in tools}
        if len(names) != 14 or any('grant' in n or 'authorize' in n for n in names):
            raise AssertionError('Unexpected or permission-mutating tools exposed')
        data=json.loads(responses[2]['result']['content'][0]['text'])
        if data['data']['roots'] != []:
            raise AssertionError('Non-empty authorized roots in clean profile')
        denied=json.loads(responses[3]['result']['content'][0]['text'])
        if denied['ok'] or denied.get('error_code')!='ACCESS_DENIED':
            raise AssertionError('Default-deny policy failed')
    print('PASS: frozen MCP starts, exposes 14 tools, default-deny works')


if __name__=='__main__':
    main()
